/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Package, LogOut, Menu, X, TableIcon, Layers, Clock, BarChart3, Upload, Download, Boxes, Pencil, Users
} from 'lucide-react';
import { 
  collection, query, orderBy, onSnapshot, doc
} from 'firebase/firestore';
import { useAuth, AuthProvider } from './lib/AuthContext';
import { db, handleFirestoreError, OperationType } from './lib/firebase';
import * as XLSX from 'xlsx';

// Types
import { 
  Tab, StockItem, ProjectEntry, UserProfile, ActivityFilter 
} from './types';

// Screens
import { TimelineScreen, TimelineFilterModal } from './screens/TimelineScreen';
import { ExcelImportScreen } from './screens/ExcelImportScreen';
import { PackingScreen } from './screens/PackingScreen';
import { ManagementScreen } from './screens/ProjectManagementScreen';
import { EditProjectScreen } from './screens/ProjectManagementScreen';
import { LoginScreen } from './screens/LoginScreen';
import { InventoryScreen } from './screens/InventoryScreen';
import { UserManagementScreen } from './screens/UserManagementScreen';

// Components
import { UserProfileModal } from './components/UserProfileModal';

function MainScreen() {
  const { user, role, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>('management');
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [projectEntries, setProjectEntries] = useState<ProjectEntry[]>([]);
  const [items, setItems] = useState<StockItem[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Navigation states
  const [showExtraMenu, setShowExtraMenu] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showTimelineFilter, setShowTimelineFilter] = useState(false);
  const [timelineFilter, setTimelineFilter] = useState<ActivityFilter>({
    projectCode: '',
    userEmail: '',
    startDate: '',
    endDate: ''
  });

  // UI Selection states for Bulk Edits
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [selectedModuleIds, setSelectedModuleIds] = useState<string[]>([]);
  const [showBulkModal, setShowBulkModal] = useState(false);

  const exportToExcel = (allProjects: boolean = false) => {
    const dataToExport = allProjects ? projectEntries : projectEntries.filter(p => p.projectCode === selectedProject);
    const projectName = dataToExport[0]?.projectName || "Unknown";
    
    const getPhaseHistory = (phaseName: string) => {
      return (entry: ProjectEntry) => {
        const history = entry.statusHistory || [];
        const phaseActions = history.filter(h => h.startsWith(phaseName));
        return phaseActions.length > 0 ? phaseActions[phaseActions.length - 1].split(' - ')[1] : '';
      };
    };

    const exportData = dataToExport.map((p, idx) => {
      return {
        'STT': idx + 1,
        'Dự Án': p.projectName,
        'Mã DA': p.displayCode || p.projectCode,
        'Cụm': p.cluster,
        'Module': p.moduleCode,
        'SL': p.quantity,
        'Giao Nhận': getPhaseHistory('Giao Nhận')(p),
        'Nguội - Sơn': getPhaseHistory('Nguội - Sơn')(p),
        'Lắp Ráp': getPhaseHistory('Lắp Ráp')(p),
        'Đóng Gói': getPhaseHistory('Đóng Gói')(p),
        'Giao Xe': getPhaseHistory('Giao Xe')(p),
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    
    const wscols = [
      { wch: 5 }, { wch: 20 }, { wch: 15 }, { wch: 15 }, { wch: 20 },
      { wch: 10 }, { wch: 30 }, { wch: 30 }, { wch: 30 }, { wch: 30 }, { wch: 30 },
    ];
    worksheet['!cols'] = wscols;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, allProjects ? "Toàn bộ dữ liệu" : "Dữ liệu dự án");
    
    const fileName = allProjects ? `Bao_cao_tong_hop.xlsx` : `Bao_cao_${projectName}_${selectedProject}.xlsx`;
    XLSX.writeFile(workbook, fileName);
    setShowExtraMenu(false);
  };

  useEffect(() => {
    if (!user) return;

    const unsubAllUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      setAllUsers(snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile)));
    });

    const unsubProfile = onSnapshot(doc(db, 'users', user.uid), (doc) => {
      if (doc.exists()) setUserProfile({ uid: doc.id, ...doc.data() } as UserProfile);
    });

    const qItems = query(collection(db, 'items'), orderBy('createdAt', 'desc'));
    const unsubItems = onSnapshot(qItems, (snapshot) => {
      setItems(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as StockItem)));
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'items');
    });

    const qProjects = query(collection(db, 'projects'), orderBy('createdAt', 'asc'));
    const unsubProjects = onSnapshot(qProjects, (snapshot) => {
      setProjectEntries(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ProjectEntry)));
      setLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'projects');
    });

    return () => {
      unsubAllUsers();
      unsubProfile();
      unsubItems();
      unsubProjects();
    };
  }, [user]);

  useEffect(() => {
    setIsSelectMode(false);
    setSelectedModuleIds([]);
  }, [selectedProject, activeTab]);

  return (
    <div className="min-h-screen bg-[#f4f6f9] flex flex-col font-sans" id="main-screen">
      <header className="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-4 sm:px-6 sticky top-0 z-50 shadow-sm" id="app-header">
        <div className="flex items-center space-x-4">
          <div 
            onClick={() => { setActiveTab('management'); setSelectedProject(null); }}
            className="flex items-center space-x-3 cursor-pointer" 
            id="header-logo"
          >
            <div className="bg-primary p-1.5 rounded-lg text-white shadow-lg shadow-primary/20">
              <Package size={24} />
            </div>
            <div className="flex flex-col">
              <h1 className="text-lg font-black text-gray-800 tracking-tighter uppercase leading-none">DRACO</h1>
              <span className="text-[9px] font-black text-primary tracking-widest leading-none mt-1">X2</span>
            </div>
          </div>

          <div className="h-8 w-px bg-gray-200 mx-1 hidden sm:block"></div>

          <div 
            onClick={() => setShowProfileModal(true)}
            className="flex items-center space-x-3 px-2 py-1 rounded-xl hover:bg-gray-50 transition-all cursor-pointer group" 
            id="user-profile-nav"
          >
            <div className="relative">
              <img 
                src={user?.photoURL || ''} 
                alt={userProfile?.ten_that || user?.displayName || 'User'} 
                referrerPolicy="no-referrer" 
                className="w-10 h-10 rounded-full border-2 border-white shadow-sm ring-1 ring-gray-100"
              />
              <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-500 border-2 border-white rounded-full"></div>
            </div>
            <div className="flex flex-col text-left">
              <span className="text-[12px] font-black text-gray-800 leading-tight group-hover:text-primary transition-colors uppercase tracking-tight">
                {userProfile?.ten_that || user?.displayName}
              </span>
              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest leading-none mt-0.5">
                {userProfile?.chuc_danh || (role === 'admin' ? 'Quản trị' : role === 'mod' ? 'Điều phối' : 'Thành viên')}
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center" id="header-actions">
          <button 
            onClick={logout}
            className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-all active:scale-95"
            title="Đăng xuất"
            id="logout-btn"
          >
            <LogOut size={20} />
          </button>
        </div>
      </header>

      <main className="flex-1 p-4 sm:p-6" id="app-content">
        <AnimatePresence mode="wait">
          {activeTab === 'management' && (
            <ManagementScreen 
              items={items} 
              projectEntries={projectEntries} 
              selectedProject={selectedProject}
              setSelectedProject={setSelectedProject}
              loading={loading}
              isSelectMode={isSelectMode}
              setIsSelectMode={setIsSelectMode}
              selectedModuleIds={selectedModuleIds}
              setSelectedModuleIds={setSelectedModuleIds}
              showBulkModal={showBulkModal}
              setShowBulkModal={setShowBulkModal}
            />
          )}
          {activeTab === 'packing' && <PackingScreen projectEntries={projectEntries} />}
          {activeTab === 'timeline' && (
            <TimelineScreen 
              filter={timelineFilter} 
              allUsers={allUsers} 
              onOpenFilter={() => setShowTimelineFilter(true)} 
            />
          )}
          {activeTab === 'excel' && <ExcelImportScreen key="excel" onComplete={() => setActiveTab('management')} />}
          {activeTab === 'edit' && (
            <EditProjectScreen 
              key="edit" 
              initialProjectCode={selectedProject} 
              projectEntries={projectEntries}
              onComplete={() => setActiveTab('management')} 
            />
          )}
          {activeTab === 'inventory' && <InventoryScreen items={items} loading={loading} />}
          {activeTab === 'users' && <UserManagementScreen allUsers={allUsers} />}
        </AnimatePresence>
      </main>

      <nav className="bg-white border-t border-gray-200 sticky bottom-0 z-20 shadow-lg px-2 flex transition-all duration-300 min-h-[64px] pb-safe py-1" id="bottom-nav">
        <div className="w-full flex items-center space-x-1">
          <div className="w-1/4 h-full relative">
            <button 
              onClick={() => setShowExtraMenu(!showExtraMenu)}
              className={`w-full h-full flex flex-col items-center justify-center space-y-1 rounded-lg transition-all ${showExtraMenu ? 'bg-primary/10 text-primary' : 'text-gray-500'}`}
              id="nav-menu-btn"
            >
              <div className="relative">
                <Menu size={22} />
                {showExtraMenu && <div className="absolute -top-1 -right-1 w-2 h-2 bg-primary rounded-full animate-ping"></div>}
              </div>
              <span className="text-[10px] font-bold uppercase">Menu</span>
            </button>
            
            <AnimatePresence>
              {showExtraMenu && (
                <>
                  <div className="fixed inset-0 z-30" onClick={() => setShowExtraMenu(false)}></div>
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute bottom-16 left-0 w-[80vw] max-w-[320px] bg-white rounded-2xl shadow-2xl border border-gray-100 p-3 z-40"
                  >
                    <div className="grid grid-cols-1 gap-3">
                      <div className="grid grid-cols-2 gap-3">
                        <button 
                          onClick={() => { setActiveTab('packing'); setShowExtraMenu(false); }}
                          className={`flex flex-col items-center justify-center p-4 rounded-xl transition-colors border ${activeTab === 'packing' ? 'bg-primary/10 border-primary text-primary' : 'bg-purple-50 hover:bg-purple-100 border-purple-100 text-purple-600'}`}
                        >
                          <Layers size={20} className="mb-1" />
                          <span className="text-[11px] font-bold uppercase tracking-tighter">Packing</span>
                        </button>
                        <button 
                          onClick={() => { setActiveTab('timeline'); setShowExtraMenu(false); }}
                          className={`flex flex-col items-center justify-center p-4 rounded-xl transition-colors border ${activeTab === 'timeline' ? 'bg-primary/10 border-primary text-primary' : 'bg-blue-50 hover:bg-blue-100 border-blue-100 text-blue-600'}`}
                        >
                          <Clock size={20} className="mb-1" />
                          <span className="text-[11px] font-bold uppercase">Timeline</span>
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-3 text-white">
                        <button 
                          onClick={() => { setActiveTab('management'); setShowExtraMenu(false); }}
                          className={`flex flex-col items-center justify-center p-4 rounded-xl transition-colors border ${activeTab === 'management' ? 'bg-primary/10 border-primary text-primary' : 'bg-indigo-50 hover:bg-indigo-100 border-indigo-100 text-indigo-600'}`}
                        >
                          <BarChart3 size={20} className="mb-1" />
                          <span className="text-[11px] font-bold uppercase tracking-tighter">Quản Lý DA</span>
                        </button>
                        <button 
                          onClick={() => { setActiveTab('edit'); setShowExtraMenu(false); }}
                          className={`flex flex-col items-center justify-center p-4 rounded-xl transition-colors border ${activeTab === 'edit' ? 'bg-primary/10 border-primary text-primary' : 'bg-amber-50 hover:bg-amber-100 border-amber-100 text-amber-600'}`}
                        >
                          <Pencil size={20} className="mb-1" />
                          <span className="text-[11px] font-bold uppercase tracking-tighter">Sửa Dự Án</span>
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <button 
                          onClick={() => { setActiveTab('excel'); setShowExtraMenu(false); }}
                          className="flex flex-col items-center justify-center p-4 bg-emerald-50 rounded-xl hover:bg-emerald-100 transition-colors border border-emerald-100"
                        >
                          <Upload size={20} className="text-emerald-600 mb-1" />
                          <span className="text-[11px] font-bold text-emerald-800 uppercase">Nhập Excel</span>
                        </button>
                        <button 
                          onClick={() => { setActiveTab('inventory'); setShowExtraMenu(false); }}
                          className="flex flex-col items-center justify-center p-4 bg-indigo-50 rounded-xl hover:bg-indigo-100 transition-colors border border-indigo-100"
                        >
                          <Boxes size={20} className="text-indigo-600 mb-1" />
                          <span className="text-[11px] font-bold text-indigo-800 uppercase">Kho hàng</span>
                        </button>
                      </div>

                      {/* Row 3: Admin Actions */}
                      <div className="grid grid-cols-2 gap-3">
                        <button 
                          onClick={() => { exportToExcel(!selectedProject); setShowExtraMenu(false); }}
                          className="flex flex-col items-center justify-center p-4 bg-orange-50 rounded-xl hover:bg-orange-100 transition-colors border border-orange-100"
                        >
                          <Download size={20} className="text-orange-600 mb-1" />
                          <span className="text-[11px] font-bold text-orange-800 uppercase leading-tight text-center">
                            Xuất Excel
                          </span>
                        </button>
                        <button 
                          onClick={() => { setActiveTab('users'); setShowExtraMenu(false); }}
                          className="flex flex-col items-center justify-center p-4 bg-red-50 rounded-xl hover:bg-red-100 transition-colors border border-red-100"
                        >
                          <Users size={20} className="text-red-600 mb-1" />
                          <span className="text-[11px] font-bold text-red-800 uppercase">Nhân viên</span>
                        </button>
                      </div>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

          <div className="w-3/4 flex items-center justify-center px-2 py-1 bg-gray-50 rounded-xl border border-gray-100 min-h-[52px]">
            {activeTab === 'management' && selectedProject ? (
              <div className="w-full flex items-center justify-between space-x-2">
                {isSelectMode ? (
                  <>
                    <div className="flex-1 flex space-x-1">
                      <button 
                        onClick={() => {
                          const allIds = projectEntries
                            .filter(p => p.projectCode === selectedProject)
                            .map(p => p.id);
                          if (selectedModuleIds.length === allIds.length) {
                            setSelectedModuleIds([]);
                          } else {
                            setSelectedModuleIds(allIds);
                          }
                        }}
                        className={`flex-1 py-2 rounded-lg text-[10px] font-bold uppercase transition-all shadow-sm ${selectedModuleIds.length > 0 ? 'bg-orange-100 text-orange-700' : 'bg-white text-gray-600 border border-gray-200'}`}
                      >
                        {selectedModuleIds.length > 0 ? 'Bỏ chọn' : 'Chọn hết'}
                      </button>
                      <button 
                        disabled={selectedModuleIds.length === 0}
                        onClick={() => setShowBulkModal(true)}
                        className="flex-1 py-2 bg-success text-white rounded-lg text-[10px] font-bold uppercase shadow-md active:scale-95 disabled:opacity-50"
                      >
                        Sửa {selectedModuleIds.length} M
                      </button>
                    </div>
                    <button 
                      onClick={() => setIsSelectMode(false)}
                      className="p-2 bg-gray-200 text-gray-700 rounded-lg"
                    >
                      <X size={18} />
                    </button>
                  </>
                ) : (
                  <>
                    <div className="flex-1 flex space-x-1 overflow-hidden">
                      <button 
                        onClick={() => document.getElementById('module-section')?.scrollIntoView({ behavior: 'smooth' })}
                        className="flex-1 py-1 px-2 bg-white border border-gray-200 rounded-lg flex flex-col items-center justify-center hover:bg-gray-50 active:scale-95"
                      >
                        <TableIcon size={14} className="text-info mb-0.5" />
                        <span className="text-[8px] font-bold text-gray-500 uppercase">Module</span>
                      </button>
                      <button 
                        onClick={() => document.getElementById('accessory-section')?.scrollIntoView({ behavior: 'smooth' })}
                        className="flex-1 py-1 px-2 bg-white border border-gray-200 rounded-lg flex flex-col items-center justify-center hover:bg-gray-50 active:scale-95"
                      >
                        <Boxes size={14} className="text-orange-500 mb-0.5" />
                        <span className="text-[8px] font-bold text-gray-500 uppercase">Phụ kiện</span>
                      </button>
                    </div>
                    <button 
                      onClick={() => setIsSelectMode(true)}
                      className="py-2 px-3 bg-primary text-white rounded-lg text-[9px] font-bold uppercase shadow-md shadow-primary/20 active:scale-95"
                    >
                      Chọn Nhiều
                    </button>
                  </>
                )}
              </div>
            ) : (
              <span className="text-sm font-black text-gray-800 uppercase tracking-widest text-center truncate">
                {activeTab === 'management' ? 'Quản Lý Dự Án' : 
                 activeTab === 'packing' ? 'Quản Lý Packing' : 
                 activeTab === 'timeline' ? 'Lịch Sử Hoạt Động' : 
                 activeTab === 'excel' ? 'Nhập Dữ Liệu Excel' : 
                 activeTab === 'edit' ? 'Chỉnh Sửa Dự Án' : 
                 activeTab === 'inventory' ? 'Kho Hàng' : 'Nhân Sự'}
              </span>
            )}
          </div>
        </div>
      </nav>

      {showTimelineFilter && (
        <TimelineFilterModal 
          filter={timelineFilter}
          setFilter={setTimelineFilter}
          onClose={() => setShowTimelineFilter(false)}
          projects={Array.from(new Set(projectEntries.map(p => p.projectCode))).filter((v): v is string => !!v).map(code => {
            const entry = projectEntries.find(prj => prj.projectCode === code);
            return { code, displayCode: entry?.displayCode };
          })}
          emails={Array.from(new Set(allUsers.map(u => u.email))).filter((v): v is string => !!v)}
        />
      )}

      {showProfileModal && userProfile && (
        <UserProfileModal 
          profile={userProfile}
          onClose={() => setShowProfileModal(false)}
        />
      )}
    </div>
  );
}

function AppContent() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F3F4F6] flex items-center justify-center" id="loading-screen">
        <motion.div 
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-xl"
          id="loading-logo"
        >
          <Package size={24} />
        </motion.div>
      </div>
    );
  }

  return user ? <MainScreen /> : <LoginScreen />;
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
