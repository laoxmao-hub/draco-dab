/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { FileSpreadsheet, X, Upload, Table as TableIcon, Loader2, CheckCircle } from 'lucide-react';
import { collection, addDoc, serverTimestamp, writeBatch, doc } from 'firebase/firestore';
import { useAuth } from '../lib/AuthContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import * as XLSX from 'xlsx';

export function ExcelImportScreen({ onComplete }: { onComplete: () => void, key?: string }) {
  const { user } = useAuth();
  const [data, setData] = useState<any[]>([]);
  const [projectInfo, setProjectInfo] = useState({ name: '', code: '' });
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      const rawData = XLSX.utils.sheet_to_json(ws);
      
      // Map common Vietnamese headers to English
      const mapped = rawData.map((row: any) => ({
        cluster: row['Cụm'] || row['CỤM'] || row['Cluster'] || '',
        moduleCode: row['Mã hàng'] || row['MÃ HÀNG'] || row['Mã Module'] || row['Module'] || '',
        quantity: Number(row['Số lượng'] || row['SỐ LƯỢNG'] || row['Qty'] || 0),
        accessoriesRaw: row['Phụ kiện'] || row['PHỤ KIỆN'] || row['Accessories'] || ''
      })).filter(r => r.moduleCode && r.quantity > 0);

      setData(mapped);
      setStep(2);
    };
    reader.readAsBinaryString(file);
  };

  const handleImport = async () => {
    if (!user || data.length === 0 || !projectInfo.name || !projectInfo.code) return;
    setLoading(true);
    const path = 'projects';
    
    try {
      const batch = writeBatch(db);
      const uniqueProjectCode = `${projectInfo.code}_${Date.now().toString().slice(-4)}`;

      data.forEach((row, idx) => {
        const docRef = doc(collection(db, path));
        
        // Parse accessories
        const accessories = row.accessoriesRaw ? row.accessoriesRaw.split(',').map((s: string) => {
          const parts = s.trim().split(':');
          return {
            name: parts[0]?.trim() || 'PK',
            quantity: Number(parts[1]?.trim()) || 1,
            issuedQuantity: 0,
            status: 'Chưa xuất kho'
          };
        }) : [];

        batch.set(docRef, {
          projectName: projectInfo.name,
          projectCode: uniqueProjectCode,
          displayCode: projectInfo.code,
          cluster: row.cluster,
          moduleCode: row.moduleCode,
          quantity: row.quantity,
          accessories,
          status: 'Giao Nhận - Chưa có',
          statusHistory: ['Giao Nhận: Chưa có'],
          ownerId: user.uid,
          createdAt: serverTimestamp(),
          sortIndex: idx
        });
      });

      await batch.commit();

      // Log activity
      await addDoc(collection(db, 'activities'), {
        userId: user.uid,
        userName: user.displayName || 'Anonymous',
        userEmail: user.email,
        action: 'Nhập Excel Dự Án',
        details: `Tạo dự án: ${projectInfo.name} (${projectInfo.code}) | ${data.length} module`,
        projectCode: uniqueProjectCode,
        timestamp: serverTimestamp()
      });

      onComplete();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6 pb-24 max-w-2xl mx-auto"
      id="excel-import-view"
    >
      <div className="flex items-center justify-between border-b border-gray-200 pb-2">
        <h2 className="text-xl font-medium text-gray-800">Nhập Dữ Liệu Excel</h2>
        <button onClick={onComplete} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <X size={20} className="text-gray-400" />
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {step === 1 ? (
          <div className="p-12 flex flex-col items-center space-y-6">
            <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600">
              <FileSpreadsheet size={40} />
            </div>
            <div className="text-center">
              <h3 className="text-lg font-bold text-gray-800 uppercase tracking-tight">Tải lên file dự án</h3>
              <p className="text-sm text-gray-500 mt-1">Hỗ trợ định dạng .xlsx, .xls</p>
            </div>
            <label className="btn-primary px-8 py-3 rounded-xl font-bold cursor-pointer transition-all active:scale-95 flex items-center space-x-2">
               <Upload size={18} />
               <span>Chọn file từ máy tính</span>
               <input type="file" className="hidden" accept=".xlsx, .xls" onChange={handleFileUpload} />
            </label>
            <div className="pt-4 grid grid-cols-2 gap-4 w-full text-[10px] text-gray-400 font-bold uppercase tracking-widest text-center border-t border-gray-50">
               <div className="p-2 border border-gray-100 rounded-lg">Cột A: Cụm</div>
               <div className="p-2 border border-gray-100 rounded-lg">Cột B: Mã Module</div>
               <div className="p-2 border border-gray-100 rounded-lg">Cột C: Số lượng</div>
               <div className="p-2 border border-gray-100 rounded-lg">Cột D: Phụ kiện</div>
            </div>
          </div>
        ) : (
          <div className="p-6 space-y-6 anim-fade-in">
            <div className="flex items-center space-x-4 p-4 bg-emerald-50 rounded-xl border border-emerald-100">
               <CheckCircle className="text-emerald-500" size={24} />
               <div>
                  <h4 className="text-sm font-bold text-emerald-800 uppercase italic">File hợp lệ</h4>
                  <p className="text-xs text-emerald-600">Đã nhận {data.length} dòng dữ liệu</p>
               </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-1">
                 <label className="text-xs font-bold text-gray-700 uppercase tracking-tight">Tên Dự Án</label>
                 <input 
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-primary shadow-inner bg-gray-50"
                    placeholder="Ví dụ: Dự án Chung cư A"
                    value={projectInfo.name}
                    onChange={e => setProjectInfo({...projectInfo, name: e.target.value})}
                 />
              </div>
              <div className="space-y-1">
                 <label className="text-xs font-bold text-gray-700 uppercase tracking-tight">Mã Dự Án (Hiển thị)</label>
                 <input 
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-primary shadow-inner bg-gray-50 font-mono"
                    placeholder="Ví dụ: DA-2024-001"
                    value={projectInfo.code}
                    onChange={e => setProjectInfo({...projectInfo, code: e.target.value.toUpperCase().replace(/\s/g, '')})}
                 />
              </div>
            </div>

            <div className="max-h-[200px] overflow-y-auto border border-gray-100 rounded-xl bg-gray-50 p-2 scrollbar-thin">
              <table className="w-full text-[10px]">
                <thead className="text-gray-400 uppercase tracking-widest text-left">
                  <tr>
                    <th className="p-2">Cụm</th>
                    <th className="p-2">Module</th>
                    <th className="p-2 text-right">SL</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {data.slice(0, 10).map((r, i) => (
                    <tr key={i}>
                       <td className="p-2 text-gray-600 font-medium uppercase">{r.cluster}</td>
                       <td className="p-2 text-gray-800 font-bold">{r.moduleCode}</td>
                       <td className="p-2 text-right font-black">{r.quantity}</td>
                    </tr>
                  ))}
                  {data.length > 10 && (
                    <tr>
                       <td colSpan={3} className="p-2 text-center text-gray-400 italic">... và {data.length - 10} dòng khác</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="flex space-x-3 pt-4">
              <button 
                 onClick={() => setStep(1)}
                 className="flex-1 py-4 bg-gray-100 text-gray-600 rounded-xl font-bold uppercase tracking-widest text-xs active:scale-95"
              >
                 Huỷ bỏ
              </button>
              <button 
                 disabled={loading || !projectInfo.name || !projectInfo.code}
                 onClick={handleImport}
                 className="flex-[2] py-4 bg-emerald-600 text-white rounded-xl font-bold uppercase tracking-widest text-xs shadow-lg shadow-emerald-100 active:scale-95 flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                 {loading ? <Loader2 size={18} className="animate-spin" /> : (
                    <>
                      <TableIcon size={18} />
                      <span>Xác nhận nhập dữ liệu</span>
                    </>
                 )}
              </button>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
