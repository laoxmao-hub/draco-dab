/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowLeft, Table as TableIcon, Menu, ChevronRight, 
  Trash2, Package, Boxes, Loader2, Upload, Pencil, X, Save, Plus, CheckCircle
} from 'lucide-react';
import { 
  doc, deleteDoc, writeBatch, query, collection, 
  where, getDocs, addDoc, serverTimestamp, updateDoc 
} from 'firebase/firestore';
import { useAuth } from '../lib/AuthContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { ProjectEntry, StockItem, Accessory } from '../types';
import { PHASES } from '../constants';

interface ManagementScreenProps {
  items: StockItem[];
  projectEntries: ProjectEntry[];
  selectedProject: string | null;
  setSelectedProject: (code: string | null) => void;
  loading: boolean;
  isSelectMode: boolean;
  setIsSelectMode: (m: boolean) => void;
  selectedModuleIds: string[];
  setSelectedModuleIds: (ids: string[] | ((prev: string[]) => string[])) => void;
  showBulkModal: boolean;
  setShowBulkModal: (b: boolean) => void;
}

export function ManagementScreen({
  items, 
  projectEntries, 
  selectedProject, 
  setSelectedProject,
  loading,
  isSelectMode,
  setIsSelectMode,
  selectedModuleIds,
  setSelectedModuleIds,
  showBulkModal,
  setShowBulkModal
}: ManagementScreenProps) {
  const { user, role } = useAuth();
  const isPrivileged = role === 'admin' || role === 'mod';
  const [selectedModuleId, setSelectedModuleId] = useState<string | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [clusterFilter, setClusterFilter] = useState<string | null>(null);
  const [selectedAccForUpdate, setSelectedAccForUpdate] = useState<{name: string, total: number, issued: number, status: string} | null>(null);
  const [showAddAccModal, setShowAddAccModal] = useState(false);

  useEffect(() => {
    setClusterFilter(null);
  }, [selectedProject]);

  const handleDeleteProject = async () => {
    if (!selectedProject) return;
    try {
      const entriesToDelete = projectEntries.filter(p => p.projectCode === selectedProject);
      const activityQuery = query(collection(db, 'activities'), where('projectCode', '==', selectedProject));
      const activitySnap = await getDocs(activityQuery);

      const batch = writeBatch(db);
      entriesToDelete.forEach(entry => {
        batch.delete(doc(db, 'projects', entry.id));
      });
      activitySnap.docs.forEach(doc => {
        batch.delete(doc.ref);
      });
      
      await batch.commit();

      await addDoc(collection(db, 'activities'), {
        userId: user?.uid,
        userName: user?.displayName || 'Anonymous',
        userEmail: user?.email || '',
        action: 'Xóa dự án',
        details: `Xóa dự án mã: ${selectedProject}`,
        timestamp: serverTimestamp()
      });

      setSelectedProject(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'projects/activities');
    }
  };

  const projects = Array.from(new Set(projectEntries.map(p => p.projectCode))).map(code => {
    const entries = projectEntries.filter(p => p.projectCode === code);
    const entry = entries[0];
    
    const statusSummary = entries.reduce((acc: any, curr) => {
      if (curr.status) {
        const lastPart = curr.status.split(' - ').pop() || '';
        acc[lastPart] = (acc[lastPart] || 0) + 1;
      }
      return acc;
    }, {});

    const sampleStatus = entries.find(e => e.status)?.status || 'Chưa có trạng thái';

    const totalAccessories = entries.reduce((acc, curr) => {
      return acc + (curr.accessories?.reduce((a, c) => a + c.quantity, 0) || 0);
    }, 0);

    return {
      code,
      displayCode: entry?.displayCode,
      name: entry?.projectName || 'Không tên',
      count: entries.reduce((acc, curr) => acc + (Number(curr.quantity) || 0), 0),
      totalAccessories,
      statusSummary,
      latestStatus: sampleStatus
    };
  }).reverse();

  const toggleSelection = (id: string) => {
    setSelectedModuleIds(prev => {
      const next = prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id];
      return next;
    });
  };

  const handleRowClick = (entry: ProjectEntry) => {
    if (isSelectMode) {
      toggleSelection(entry.id);
    } else {
      setSelectedModuleId(entry.id);
    }
  };

  if (selectedProject) {
    const rawEntries = projectEntries.filter(p => p.projectCode === selectedProject).sort((a, b) => (a.sortIndex || 0) - (b.sortIndex || 0));
    const clusters = Array.from(new Set(rawEntries.map(e => e.cluster))).filter((v): v is string => !!v).sort();
    const entries = clusterFilter ? rawEntries.filter(e => e.cluster === clusterFilter) : rawEntries;
    const currentModule = selectedModuleId ? rawEntries.find(e => e.id === selectedModuleId) : null;

    return (
      <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4 pb-24">
        <button onClick={() => setSelectedProject(null)} className="flex items-center text-sm text-gray-500 hover:text-primary transition-colors mb-2">
          <ArrowLeft size={16} className="mr-1" /> Quay lại danh sách
        </button>
        <div className="flex items-center justify-between border-b border-gray-200 pb-2">
          <h2 className="text-xl font-medium text-gray-800">{rawEntries[0]?.projectName || ''}</h2>
          <span className="text-xs font-bold bg-primary/10 text-primary px-2 py-0.5 rounded">{entries[0]?.displayCode || selectedProject}</span>
        </div>

        <div id="module-section" className="bg-white rounded shadow-sm border-t-4 border-info overflow-hidden relative">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <TableIcon size={16} className="text-info" />
              <h3 className="text-sm font-semibold text-gray-700">Chi tiết Module {selectedModuleIds.length > 0 && `(Đang chọn ${selectedModuleIds.length})`}</h3>
            </div>
            <div className="flex items-center bg-gray-50 border border-gray-200 rounded px-2 py-0.5">
              <Menu size={10} className="text-gray-400 mr-1" />
              <select value={clusterFilter || ''} onChange={e => setClusterFilter(e.target.value || null)} className="text-[10px] font-bold text-gray-600 bg-transparent outline-none border-none cursor-pointer uppercase tracking-tight">
                <option value="">Tất cả Cụm</option>
                {clusters.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  {isSelectMode && <th className="px-4 py-2 w-10">
                    <input type="checkbox" checked={entries.length > 0 && entries.every(e => selectedModuleIds.includes(e.id))} onChange={() => {
                        const entryIds = entries.map(e => e.id);
                        if (entryIds.every(id => selectedModuleIds.includes(id))) {
                          setSelectedModuleIds(prev => prev.filter(id => !entryIds.includes(id)));
                        } else {
                          setSelectedModuleIds(prev => Array.from(new Set([...prev, ...entryIds])));
                        }
                      }} className="w-4 h-4 rounded text-primary border-gray-300 focus:ring-primary cursor-pointer" />
                  </th>}
                  <th className="px-4 py-2 text-[10px] font-bold text-gray-500 uppercase">Module / Cụm</th>
                  <th className="px-4 py-2 text-[10px] font-bold text-gray-500 uppercase text-right">SL</th>
                  <th className="px-4 py-2 text-[10px] font-bold text-gray-500 uppercase pl-6 text-center">Trạng thái (5 gần nhất)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {entries.map(entry => {
                  const isSelected = selectedModuleIds.includes(entry.id);
                  return (
                    <tr key={entry.id} className={`hover:bg-gray-50/50 transition-colors cursor-pointer group select-none ${isSelected ? 'bg-blue-50' : ''}`} onClick={() => handleRowClick(entry)}>
                      {isSelectMode && <td className="px-4 py-3"><input type="checkbox" checked={isSelected} readOnly className="w-4 h-4 rounded text-primary border-gray-300 focus:ring-primary pointer-events-none" /></td>}
                      <td className="px-4 py-3">
                        <div className="flex flex-col">
                          <span className="text-[10px] text-gray-400 font-bold uppercase mb-0.5">{entry.cluster || 'N/A'}</span>
                          <div className="flex items-center text-sm font-bold text-gray-800">
                            {entry.moduleCode}
                            {!isSelectMode && <ChevronRight size={12} className="ml-1 opacity-0 group-hover:opacity-100 transition-opacity text-primary" />}
                          </div>
                          {entry.accessories && entry.accessories.length > 0 && (
                            <div className="mt-1 flex flex-wrap gap-1">
                              {entry.accessories.map((a, i) => {
                                const isComplete = (a.issuedQuantity || 0) >= a.quantity && a.quantity > 0 && (a.status === 'Xuất kho lắp ráp' || a.status === 'Xuất kho đóng gói');
                                const borderColorClass = isComplete && a.status === 'Xuất kho lắp ráp' ? 'border-green-300' : isComplete && a.status === 'Xuất kho đóng gói' ? 'border-blue-300' : a.status === 'Chờ đặt hàng' ? 'border-orange-300' : a.status === 'Chưa có hàng' ? 'border-red-300' : a.status === 'Chưa xuất kho' ? 'border-gray-200' : 'border-gray-100';
                                const bgClass = isComplete && a.status === 'Xuất kho lắp ráp' ? 'bg-green-50' : isComplete && a.status === 'Xuất kho đóng gói' ? 'bg-blue-50' : a.status === 'Chờ đặt hàng' ? 'bg-orange-50' : a.status === 'Chưa có hàng' ? 'bg-red-50' : a.status === 'Chưa xuất kho' ? 'bg-gray-50' : 'bg-gray-50';
                                return <span key={i} className={`text-[8px] ${bgClass} text-gray-500 px-1 py-0 rounded border ${borderColorClass} font-bold uppercase`}>{a.name}: {a.quantity}</span>;
                              })}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-right font-bold text-gray-600">{entry.quantity}</td>
                      <td className="px-4 py-3 pl-6">
                        <div className="flex flex-wrap gap-1.5 justify-center">
                          {entry.statusHistory?.slice(-5).reverse().map((h, i) => (
                            <div key={i} className={`px-2 py-0.5 border rounded text-[9px] leading-tight ${i === 0 ? 'bg-blue-50 border-blue-200 text-blue-700 font-bold' : 'bg-gray-50 border-gray-100 text-gray-400 font-normal'}`}>{h}</div>
                          )) || <span className="text-[10px] text-gray-300 italic">Chưa có cập nhật</span>}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div id="accessory-section" className="mt-8 space-y-4">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center space-x-2">
              <Boxes size={20} className="text-orange-500" />
              <h3 className="text-base font-bold text-gray-800 uppercase tracking-wide">Bảng Tổng Hợp Phụ Kiện Dự Án</h3>
            </div>
            <button onClick={() => setShowAddAccModal(true)} className="w-8 h-8 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center hover:bg-orange-500 hover:text-white transition-all shadow-sm active:scale-90" title="Thêm phụ kiện mới"><Plus size={18} /></button>
          </div>
          <div className="bg-white rounded-xl shadow-lg border border-orange-100 overflow-hidden">
            <div className="p-4 bg-orange-50/50 border-b border-orange-100 flex items-center justify-between">
              <span className="text-[10px] font-black text-orange-600 uppercase tracking-widest">Thông tin chi tiết phụ kiện</span>
              <div className="flex items-center space-x-2"><div className="w-2 h-2 rounded-full bg-orange-400 animate-pulse"></div><span className="text-[10px] font-bold text-orange-500 uppercase">Đã tổng hợp từ {entries.length} module</span></div>
            </div>
            <div className="overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr><th className="px-4 py-3 text-[10px] font-bold text-gray-500 uppercase w-12 text-center">STT</th><th className="px-4 py-3 text-[10px] font-bold text-gray-500 uppercase">Tên Phụ Kiện</th><th className="px-4 py-3 text-[10px] font-bold text-gray-500 uppercase text-right">Số lượng (Xuất/Tổng)</th></tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {(() => {
                    const accMap = entries.reduce((acc: any, entry) => {
                      entry.accessories?.forEach(a => {
                        if (!acc[a.name]) acc[a.name] = { total: 0, issued: 0, status: '' };
                        acc[a.name].total += a.quantity;
                        acc[a.name].issued += (a.issuedQuantity || 0);
                        if (a.status) acc[a.name].status = a.status;
                      });
                      return acc;
                    }, {});
                    const sortedAccs = Object.entries(accMap).sort();
                    return sortedAccs.length > 0 ? sortedAccs.map(([name, data]: [any, any], idx) => {
                      const isComplete = data.issued >= data.total && data.total > 0 && (data.status === 'Xuất kho lắp ráp' || data.status === 'Xuất kho đóng gói');
                      const dotColor = isComplete && data.status === 'Xuất kho lắp ráp' ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.4)]' : isComplete && data.status === 'Xuất kho đóng gói' ? 'bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.4)]' : data.status === 'Chờ đặt hàng' ? 'bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.4)]' : data.status === 'Chưa có hàng' ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.4)]' : data.status === 'Chưa xuất kho' ? 'bg-gray-200' : 'bg-gray-300';
                      return (
                        <tr key={name} onClick={() => setSelectedAccForUpdate({ name, total: data.total, issued: data.issued, status: data.status || 'Chưa xuất kho' })} className="hover:bg-orange-50/20 transition-colors group cursor-pointer">
                          <td className="px-4 py-3 text-[11px] font-bold text-gray-400 text-center">{idx + 1}</td>
                          <td className="px-4 py-3"><div className="flex items-center space-x-2"><div className={`w-2 h-2 rounded-full ${dotColor} transition-all`} /><span className="text-sm font-bold text-gray-800 group-hover:text-primary transition-colors">{name}</span>{isComplete && <span className="ml-1 text-[8px] bg-green-100 text-green-600 px-1.5 py-0.5 rounded-full font-black uppercase tracking-tighter border border-green-200">Đã xuất đủ</span>}</div></td>
                          <td className="px-4 py-3 text-sm text-right font-black tabular-nums"><span className="text-orange-600">{data.issued}</span><span className="text-gray-300 mx-1">/</span><span className="text-gray-400">{data.total}</span></td>
                        </tr>
                      );
                    }) : <tr><td colSpan={3} className="px-6 py-12 text-center text-gray-400 italic text-xs"><div className="flex flex-col items-center space-y-2"><Boxes size={32} className="opacity-20" /><span>Dự án này không có vật tư phụ kiện.</span></div></td></tr>;
                  })()}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {isPrivileged && (
          <div className="mt-12 pt-8 border-t border-gray-200">
            <div className="bg-red-50 rounded-xl p-6 border border-red-100 flex flex-col items-center space-y-4">
              <button onClick={() => setShowDeleteModal(true)} className="btn-danger px-8 py-3 rounded-lg font-bold text-xs uppercase tracking-widest shadow-lg shadow-red-100 flex items-center space-x-2"><Trash2 size={16} /><span>Xóa Dự Án</span></button>
            </div>
          </div>
        )}

        {showDeleteModal && <DeleteConfirmationModal projectCode={selectedProject} onConfirm={handleDeleteProject} onClose={() => setShowDeleteModal(false)} />}
        {showBulkModal && <StatusUpdateModal onClose={() => { setShowBulkModal(false); setSelectedModuleIds([]); setIsSelectMode(false); }} entries={entries} preSelectedIds={selectedModuleIds} />}
        {currentModule && <ModuleDetailModal key={selectedModuleId} module={currentModule} onClose={() => setSelectedModuleId(null)} projectAccessories={Array.from(new Set(entries.flatMap(e => e.accessories || []).map(a => a.name)))} />}
        {selectedAccForUpdate && <AccessoryUpdateModal accessoryName={selectedAccForUpdate.name} totalRequired={selectedAccForUpdate.total} currentIssued={selectedAccForUpdate.issued} currentStatus={selectedAccForUpdate.status} projectCode={selectedProject} onClose={() => setSelectedAccForUpdate(null)} />}
        {showAddAccModal && <AddProjectAccessoryModal projectCode={selectedProject} projectEntries={projectEntries} onClose={() => setShowAddAccModal(false)} />}
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6 pb-24" id="management-view">
      <div className="flex items-center justify-between border-b border-gray-200 pb-2">
        <h2 className="text-xl font-medium text-gray-800">Quản Lý Dự Án</h2>
        <span className="text-xs text-gray-500 font-normal">Tổng: {projects.length} dự án</span>
      </div>
      <div className="space-y-3">
        {projects.length > 0 ? projects.map(p => (
            <div key={p.code} onClick={() => setSelectedProject(p.code)} className="bg-white p-4 rounded shadow-sm border-l-4 border-primary flex items-center justify-between cursor-pointer hover:bg-gray-50 transition-colors">
              <div className="flex-1 flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-50 rounded flex items-center justify-center text-primary font-bold">{p.name.charAt(0).toUpperCase()}</div>
                <div className="min-w-0 pr-4">
                  <div className="flex items-center space-x-2"><h4 className="text-sm font-bold text-gray-800 truncate">{p.name}</h4><span className="text-[9px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded font-bold uppercase tracking-tighter border border-gray-200">{p.displayCode || p.code}</span></div>
                  <p className="text-[10px] text-gray-500 uppercase tracking-tight mt-0.5">{p.count} Module • {p.totalAccessories} Phụ kiện</p>
                  <div className="mt-1 flex items-center space-x-1"><div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></div><span className="text-[9px] text-primary font-bold uppercase tracking-tight truncate max-w-[200px]">{p.latestStatus}</span></div>
                </div>
              </div>
              <div className="flex items-center space-x-4"><div className="hidden md:flex flex-wrap gap-1 justify-end max-w-[200px]">{Object.entries(p.statusSummary).map(([status, count]) => <span key={status} className="text-[8px] bg-gray-100 px-1.5 py-0.5 rounded text-gray-600 font-bold uppercase truncate">{status}: {count as any}</span>)}</div><ChevronRight size={18} className="text-gray-300" /></div>
            </div>
          )) : <div className="bg-white p-12 rounded shadow-sm border border-gray-100 flex flex-col items-center justify-center text-gray-400 space-y-4"><Package size={48} className="opacity-20" /><p className="text-sm italic">Chưa có dự án nào được nhập.</p></div>}
      </div>
    </motion.div>
  );
}

export function EditProjectScreen({ onComplete, initialProjectCode, projectEntries }: { onComplete: () => void, initialProjectCode: string | null, projectEntries: ProjectEntry[], key?: string }) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [selectedCode, setSelectedCode] = useState(initialProjectCode || '');
  const [projectName, setProjectName] = useState('');
  const projects = Array.from(new Set(projectEntries.map(p => p.projectCode))).map(code => {
    const entry = projectEntries.find(p => p.projectCode === code);
    return { code, name: entry?.projectName || 'Không tên', displayCode: entry?.displayCode };
  }).reverse();
  const [entries, setEntries] = useState<ProjectEntry[]>([]);

  useEffect(() => {
    if (selectedCode) {
      const p = projects.find(p => p.code === selectedCode);
      if (p) setProjectName(p.name);
      const pEntries = projectEntries.filter(p => p.projectCode === selectedCode);
      setEntries(JSON.parse(JSON.stringify(pEntries)));
    } else {
      setProjectName('');
      setEntries([]);
    }
  }, [selectedCode]);

  const handleEntryChange = (id: string, field: keyof ProjectEntry, value: any) => {
    setEntries(prev => prev.map(e => e.id === id ? { ...e, [field]: value } : e));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !selectedCode) return;
    setLoading(true);
    try {
      const batch = writeBatch(db);
      for (const entry of entries) {
        batch.update(doc(db, 'projects', entry.id), { projectName, cluster: entry.cluster, moduleCode: entry.moduleCode, quantity: Number(entry.quantity) || 0 });
      }
      await batch.commit();
      await addDoc(collection(db, 'activities'), {
        userId: user.uid, userName: user.displayName || 'Anonymous', userEmail: user.email,
        action: 'Chỉnh sửa dự án', details: `Cập nhật dự án: ${projectName} (${selectedCode})`,
        projectCode: selectedCode, timestamp: serverTimestamp()
      });
      onComplete();
    } catch (error: any) {
      handleFirestoreError(error, OperationType.WRITE, 'projects');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 pb-24">
      <div className="flex items-center justify-between mb-4 border-b border-gray-200 pb-2"><h2 className="text-xl font-medium text-gray-800">Cập Nhật Dự Án</h2></div>
      <div className="bg-white rounded shadow-sm border-t-4 border-primary p-6 space-y-6">
        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-bold text-gray-700 uppercase">Chọn Dự Án Đang Có</label>
            <select className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:border-primary outline-none" value={selectedCode} onChange={e => setSelectedCode(e.target.value)} disabled={!!initialProjectCode}>
              <option value="">-- Chọn một dự án --</option>
              {projects.map(p => <option key={p.code} value={p.code}>{p.name} ({p.displayCode || p.code})</option>)}
            </select>
            {initialProjectCode && <p className="text-[10px] text-primary font-bold mt-1 uppercase">Đang chỉnh sửa dự án đã chọn</p>}
          </div>
          {selectedCode && (
            <form onSubmit={handleSubmit} className="space-y-6 anim-fade-in">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-700 uppercase">Tên Dự Án</label>
                <input required className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-primary" placeholder="Tên dự án" value={projectName} onChange={e => setProjectName(e.target.value)} />
              </div>
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest border-b border-gray-100 pb-2">Danh sách Module</h3>
                <div className="space-y-3">
                  {entries.map((entry, idx) => (
                    <div key={entry.id} className="p-3 bg-gray-50 rounded border border-gray-200 space-y-3">
                      <div className="flex items-center justify-between"><span className="text-[10px] font-bold text-gray-400 uppercase">Module #{idx + 1}</span></div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1"><label className="text-[10px] font-bold text-gray-500 uppercase">Cụm</label><input className="w-full border border-gray-300 rounded px-2 py-1.5 text-xs focus:border-primary outline-none" value={entry.cluster} onChange={e => handleEntryChange(entry.id, 'cluster', e.target.value)} /></div>
                        <div className="space-y-1"><label className="text-[10px] font-bold text-gray-500 uppercase">Mã hàng</label><input className="w-full border border-gray-300 rounded px-2 py-1.5 text-xs focus:border-primary outline-none" value={entry.moduleCode} onChange={e => handleEntryChange(entry.id, 'moduleCode', e.target.value)} /></div>
                      </div>
                      <div className="space-y-1"><label className="text-[10px] font-bold text-gray-500 uppercase">Số lượng</label><input type="number" className="w-full border border-gray-300 rounded px-2 py-1.5 text-xs focus:border-primary outline-none" value={entry.quantity} onChange={e => handleEntryChange(entry.id, 'quantity', e.target.value)} /></div>
                    </div>
                  ))}
                </div>
              </div>
              <button disabled={loading} type="submit" className="w-full btn-primary font-bold py-3 rounded shadow-sm flex items-center justify-center space-x-2 disabled:opacity-50">{loading ? <Loader2 size={18} className="animate-spin" /> : <span>LƯU TẤT CẢ THAY ĐỔI</span>}</button>
            </form>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function DeleteConfirmationModal({ projectCode, onConfirm, onClose }: { projectCode: string, onConfirm: () => void, onClose: () => void }) {
  const [confirmCode, setConfirmCode] = useState('');
  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[100] p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-white w-full max-w-sm rounded-xl shadow-2xl overflow-hidden p-6">
        <h3 className="text-lg font-bold text-red-600 uppercase mb-4">Cảnh báo quan trọng</h3>
        <p className="text-sm text-gray-600 mb-6">Bạn đang thực hiện xóa toàn bộ dự án <strong>{projectCode}</strong>. Hành động này sẽ xóa tất cả module và lịch sử đi kèm.</p>
        <div className="space-y-4">
          <p className="text-[10px] font-bold text-gray-400 uppercase">Nhập lại mã dự án để xác nhận:</p>
          <input className="w-full border border-red-200 rounded px-3 py-2 text-sm focus:border-red-500 outline-none font-mono" placeholder={projectCode} value={confirmCode} onChange={e => setConfirmCode(e.target.value)} />
          <div className="flex space-x-3 pt-4">
            <button onClick={onClose} className="flex-1 py-2 text-gray-500 font-bold text-xs">HUỶ</button>
            <button disabled={confirmCode !== projectCode} onClick={onConfirm} className="flex-1 py-2 bg-red-600 text-white rounded font-bold text-xs disabled:opacity-30">XÓA VĨNH VIỄN</button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function StatusUpdateModal({ onClose, entries, preSelectedIds }: { onClose: () => void, entries: ProjectEntry[], preSelectedIds: string[] }) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const selectedEntries = entries.filter(e => preSelectedIds.includes(e.id));
  const [selectedPhase, setSelectedPhase] = useState('Giao Nhận');
  const [selectedStatus, setSelectedStatus] = useState(PHASES['Giao Nhận'][0]);

  const handleUpdate = async () => {
    if (!user || selectedEntries.length === 0) return;
    setLoading(true);
    try {
      const batch = writeBatch(db);
      const fullStatus = `${selectedPhase} - ${selectedStatus}`;
      const logRef = doc(collection(db, 'activities'));
      
      batch.set(logRef, {
        userId: user.uid, userName: user.displayName || 'Anonymous', userEmail: user.email,
        action: 'Cập nhật trạng thái', details: `Cập nhật ${selectedEntries.length} module lên: ${fullStatus}`,
        projectCode: selectedEntries[0]?.projectCode, timestamp: serverTimestamp()
      });

      for (const entry of selectedEntries) {
        const docRef = doc(db, 'projects', entry.id);
        const history = [...(entry.statusHistory || [])];
        if (history[history.length - 1] !== fullStatus) history.push(fullStatus);
        batch.update(docRef, { status: fullStatus, statusHistory: history });
      }

      await batch.commit();
      onClose();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'projects');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[110] p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-white w-full max-w-sm rounded-xl shadow-2xl overflow-hidden p-6 space-y-6">
        <h3 className="text-lg font-bold text-gray-800 uppercase">Cập nhật {selectedEntries.length} Module</h3>
        <div className="space-y-4">
          <div className="space-y-1"><label className="text-[10px] font-bold text-gray-400 uppercase">Chọn Công Đoạn</label><select className="w-full border rounded px-3 py-2 text-sm focus:border-primary outline-none" value={selectedPhase} onChange={e => { setSelectedPhase(e.target.value); setSelectedStatus(PHASES[e.target.value][0]); }}>{Object.keys(PHASES).map(p => <option key={p} value={p}>{p}</option>)}</select></div>
          <div className="space-y-1"><label className="text-[10px] font-bold text-gray-400 uppercase">Trạng Thái Chi Tiết</label><select className="w-full border rounded px-3 py-2 text-sm focus:border-primary outline-none" value={selectedStatus} onChange={e => setSelectedStatus(e.target.value)}>{PHASES[selectedPhase].map(s => <option key={s} value={s}>{s}</option>)}</select></div>
        </div>
        <div className="flex space-x-3 pt-4"><button onClick={onClose} className="flex-1 py-2 text-gray-400 font-bold text-xs uppercase">Huỷ</button><button disabled={loading} onClick={handleUpdate} className="flex-1 py-3 bg-success text-white rounded font-bold text-xs uppercase shadow-lg shadow-green-100 disabled:opacity-50 flex items-center justify-center">{loading ? <Loader2 size={16} className="animate-spin" /> : 'Lưu cập nhật'}</button></div>
      </motion.div>
    </div>
  );
}

function ModuleDetailModal({ module, onClose, projectAccessories = [] }: { module: ProjectEntry, onClose: () => void, projectAccessories?: string[], key?: string }) {
  const { user, role } = useAuth();
  const isPrivileged = role === 'admin' || role === 'mod';
  const [isEditing, setIsEditing] = useState(false);
  const [editCluster, setEditCluster] = useState(module.cluster || '');
  const [editModuleCode, setEditModuleCode] = useState(module.moduleCode || '');
  const [editQuantity, setEditQuantity] = useState(module.quantity || 0);
  const [editAccessories, setEditAccessories] = useState<Accessory[]>(module.accessories || []);
  const [saveLoading, setSaveLoading] = useState(false);

  const handleSaveInfo = async () => {
    if (!user || !module.id) return;
    setSaveLoading(true);
    try {
      await updateDoc(doc(db, 'projects', module.id), { cluster: editCluster, moduleCode: editModuleCode, quantity: Number(editQuantity), accessories: editAccessories });
      await addDoc(collection(db, 'activities'), {
        userId: user.uid, userName: user.displayName || 'Anonymous', userEmail: user.email,
        action: 'Sửa thông tin module', details: `Cụm: ${editCluster} | Mã: ${editModuleCode} | SL: ${editQuantity} | PK: ${editAccessories.map(a => `${a.name}(${a.quantity})`).join(', ')}`,
        projectCode: module.projectCode, moduleCode: editModuleCode, timestamp: serverTimestamp()
      });
      setIsEditing(false);
    } catch (error: any) {
      handleFirestoreError(error, OperationType.UPDATE, 'projects');
    } finally {
      setSaveLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-white w-full max-w-lg rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-primary text-white">
          <div className="flex-1 mr-4">{isEditing ? <div className="space-y-2"><input className="w-full bg-white/10 border border-white/20 rounded px-2 py-1 text-sm font-bold text-white outline-none focus:bg-white/20" value={editModuleCode} onChange={e => setEditModuleCode(e.target.value)} /><div className="flex space-x-2"><input className="flex-1 bg-white/10 border border-white/20 rounded px-2 py-1 text-[10px] text-white outline-none focus:bg-white/20" value={editCluster} onChange={e => setEditCluster(e.target.value)} /><input type="number" className="w-20 bg-white/10 border border-white/20 rounded px-2 py-1 text-[10px] text-white outline-none focus:bg-white/20" value={editQuantity} onChange={e => setEditQuantity(Number(e.target.value))} /></div></div> : <><h3 className="font-bold text-sm uppercase tracking-wider">Chi tiết Module: {module.moduleCode}</h3><p className="text-[10px] opacity-80 uppercase">{module.projectName} • Cụm: {module.cluster || 'N/A'} • SL: {module.quantity}</p></>}</div>
          <div className="flex items-center space-x-2">
            {isPrivileged && (isEditing ? <button onClick={handleSaveInfo} disabled={saveLoading} className="p-2 bg-success text-white rounded-full transition-transform disabled:opacity-50">{saveLoading ? <Loader2 size={20} className="animate-spin" /> : <Upload size={20} />}</button> : <button onClick={() => setIsEditing(true)} className="p-2 hover:bg-white/20 rounded-full transition-colors"><Pencil size={20} /></button>)}
            <button onClick={onClose} className="p-2 hover:bg-white/20 rounded-full transition-colors"><X size={20} /></button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-thin">
            <div className="bg-gray-50 rounded-lg p-3 border border-gray-100 flex justify-between items-center"><div className="space-y-1"><span className="text-[10px] text-gray-400 font-bold uppercase block">Thông tin Module</span><div className="flex items-center space-x-3"><div><p className="text-[10px] text-gray-500 uppercase">Module</p><p className="text-sm font-bold text-gray-800">{module.moduleCode}</p></div><div className="h-4 border-l border-gray-200"></div><div><p className="text-[10px] text-gray-500 uppercase">Cụm</p><p className="text-sm font-bold text-gray-800">{module.cluster || 'N/A'}</p></div><div className="h-4 border-l border-gray-200"></div><div><p className="text-[10px] text-gray-500 uppercase">Số lượng</p><p className="text-sm font-bold text-gray-800">{module.quantity}</p></div></div>{module.accessories && module.accessories.length > 0 && <div className="mt-4 space-y-2 pt-4 border-t border-gray-100"><p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Danh sách Phụ kiện Module</p><div className="grid grid-cols-2 gap-2">{module.accessories.map((a, i) => {
                       const isComplete = (a.issuedQuantity || 0) >= a.quantity && a.quantity > 0 && (a.status === 'Xuất kho lắp ráp' || a.status === 'Xuất kho đóng gói');
                       const borderColorClass = isComplete && a.status === 'Xuất kho lắp ráp' ? 'border-green-300' : isComplete && a.status === 'Xuất kho đóng gói' ? 'border-blue-300' : a.status === 'Chờ đặt hàng' ? 'border-orange-300' : a.status === 'Chưa có hàng' ? 'border-red-300' : a.status === 'Chưa xuất kho' ? 'border-gray-200' : 'border-gray-200';
                       const bgClass = isComplete && a.status === 'Xuất kho lắp ráp' ? 'bg-green-50/50' : isComplete && a.status === 'Xuất kho đóng gói' ? 'bg-blue-50/50' : a.status === 'Chờ đặt hàng' ? 'bg-orange-50/50' : a.status === 'Chưa có hàng' ? 'bg-red-50/50' : a.status === 'Chưa xuất kho' ? 'bg-gray-50/50' : 'bg-gray-50/50';
                       return <div key={i} className={`flex items-center justify-between ${bgClass} px-3 py-1.5 rounded-lg border ${borderColorClass} group transition-colors`}><div className="flex items-center space-x-2"><span className="text-[11px] font-bold text-gray-500 uppercase">{a.name}</span></div><span className="text-xs font-black text-gray-400">x{a.quantity}</span></div>;
                    })}</div></div>}</div></div>

            {isEditing && (
              <div className="space-y-3 pt-4 border-t border-gray-100">
                <div className="flex items-center justify-between"><h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Chỉnh sửa Phụ kiện</h4><button onClick={() => setEditAccessories([...editAccessories, { name: '', quantity: 1, status: 'Chưa xuất kho' }])} className="text-[10px] font-bold text-primary flex items-center uppercase"><Plus size={12} className="mr-1" /> Thêm</button></div>
                <div className="space-y-2">
                  {editAccessories.map((a, idx) => (
                    <div key={idx} className="flex items-center space-x-2 bg-gray-50 p-2 rounded-lg border border-gray-200">
                      <input list="suggested-acc" className="flex-1 bg-white border border-gray-200 rounded px-2 py-1 text-xs outline-none focus:border-primary" value={a.name} onChange={e => { const next = [...editAccessories]; next[idx].name = e.target.value; setEditAccessories(next); }} placeholder="Tên PK" />
                      <input type="number" className="w-16 bg-white border border-gray-200 rounded px-2 py-1 text-xs outline-none focus:border-primary text-center" value={a.quantity} onChange={e => { const next = [...editAccessories]; next[idx].quantity = Number(e.target.value); setEditAccessories(next); }} />
                      <button onClick={() => setEditAccessories(editAccessories.filter((_, i) => i !== idx))} className="text-red-400"><Trash2 size={16} /></button>
                    </div>
                  ))}
                  <datalist id="suggested-acc">{projectAccessories.map(name => <option key={name} value={name} />)}</datalist>
                </div>
              </div>
            )}

            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Lịch sử công đoạn</h4>
              <div className="space-y-4">
                {Object.entries(PHASES).map(([phase, statusList]) => {
                  const history = (module.statusHistory || []).filter(h => h.startsWith(phase));
                  const latest = history.length > 0 ? history[history.length - 1] : null;

                  return (
                    <div key={phase} className="relative pl-6 border-l-2 border-gray-100 space-y-2">
                      <div className="absolute -left-[5px] top-0 w-2 h-2 rounded-full bg-gray-200 border border-white"></div>
                      <div className="flex items-center justify-between">
                         <span className="text-xs font-black text-gray-800 uppercase tracking-tight">{phase}</span>
                         {latest && <span className="text-[9px] bg-blue-50 text-blue-600 px-2 py-0.5 rounded font-black uppercase tracking-tight">{latest.split(' - ')[1]}</span>}
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {statusList.map(s => {
                          const isCurrent = latest === `${phase} - ${s}`;
                          return (
                             <button key={s} disabled={!isPrivileged} onClick={() => {
                                if (isCurrent) return;
                                const fullStatus = `${phase} - ${s}`;
                                const newHistory = [...(module.statusHistory || [])];
                                newHistory.push(fullStatus);
                                updateDoc(doc(db, 'projects', module.id), { status: fullStatus, statusHistory: newHistory });
                                addDoc(collection(db, 'activities'), {
                                  userId: user?.uid, userName: user?.displayName || 'Anonymous', userEmail: user?.email || '',
                                  action: 'Cập nhật trạng thái', details: `Module ${module.moduleCode}: ${fullStatus}`,
                                  projectCode: module.projectCode, moduleCode: module.moduleCode, timestamp: serverTimestamp()
                                });
                             }} className={`px-2 py-1 rounded text-[9px] font-bold uppercase transition-all ${isCurrent ? 'bg-primary text-white shadow-md' : 'bg-white border border-gray-100 text-gray-400 hover:border-primary hover:text-primary'}`}>{s}</button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
        </div>
      </motion.div>
    </div>
  );
}

function AccessoryUpdateModal({ accessoryName, totalRequired, currentIssued, currentStatus, projectCode, onClose }: { accessoryName: string, totalRequired: number, currentIssued: number, currentStatus: string, projectCode: string | null, onClose: () => void }) {
  const { user } = useAuth();
  const [issuedValue, setIssuedValue] = useState(currentIssued);
  const [status, setStatus] = useState(currentStatus || 'Chưa xuất kho');
  const [loading, setLoading] = useState(false);

  const handleUpdate = async () => {
    if (!user || !projectCode) return;
    setLoading(true);
    try {
      const q = query(collection(db, 'projects'), where('projectCode', '==', projectCode));
      const snap = await getDocs(q);
      const batch = writeBatch(db);
      
      let remainingToUpdate = issuedValue;
      snap.docs.forEach(docSnap => {
        const data = docSnap.data();
        let accessories = [...(data.accessories || [])];
        let changed = false;
        
        accessories = accessories.map(a => {
           if (a.name === accessoryName) {
              changed = true;
              const take = Math.min(remainingToUpdate, a.quantity);
              remainingToUpdate -= take;
              return { ...a, issuedQuantity: take, status: status };
           }
           return a;
        });
        if (changed) batch.update(docSnap.ref, { accessories });
      });

      await batch.commit();
      await addDoc(collection(db, 'activities'), {
        userId: user.uid, userName: user.displayName || 'Anonymous', userEmail: user.email,
        action: 'Cập nhật phụ kiện bộ', details: `PK ${accessoryName}: Xuất ${issuedValue}/${totalRequired} (${status})`,
        projectCode, timestamp: serverTimestamp()
      });
      onClose();
    } catch (e: any) {
      handleFirestoreError(e, OperationType.UPDATE, 'projects');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[110] p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-white w-full max-w-sm rounded-xl shadow-2xl overflow-hidden p-6 space-y-6">
        <h3 className="text-lg font-bold text-gray-800 uppercase">Cập nhật Phụ kiện: {accessoryName}</h3>
        <div className="space-y-4">
          <div className="space-y-1"><label className="text-[10px] font-bold text-gray-400 uppercase">SỐ LƯỢNG ĐÃ XUẤT (TỔNG {totalRequired})</label><input type="number" max={totalRequired} className="w-full border rounded-xl px-4 py-3 text-sm focus:border-primary outline-none bg-gray-50" value={issuedValue} onChange={e => setIssuedValue(Number(e.target.value))} /></div>
          <div className="space-y-1"><label className="text-[10px] font-bold text-gray-400 uppercase">TRẠNG THÁI VẬT TƯ</label><select className="w-full border rounded-xl px-4 py-3 text-sm focus:border-primary outline-none bg-gray-50" value={status} onChange={e => setStatus(e.target.value)}><option value="Chưa xuất kho">Chưa xuất kho</option><option value="Chưa có hàng">Chưa có hàng</option><option value="Chờ đặt hàng">Chờ đặt hàng</option><option value="Xuất kho lắp ráp">Xuất kho lắp ráp</option><option value="Xuất kho đóng gói">Xuất kho đóng gói</option></select></div>
        </div>
        <div className="flex space-x-3 pt-4"><button onClick={onClose} className="flex-1 py-3 text-gray-400 font-bold text-[10px] uppercase">Huỷ</button><button disabled={loading} onClick={handleUpdate} className="flex-[2] py-4 bg-primary text-white rounded-xl font-bold text-xs uppercase shadow-lg shadow-primary/20 disabled:opacity-50">{loading ? <Loader2 size={18} className="animate-spin mx-auto" /> : 'Lưu thay đổi'}</button></div>
      </motion.div>
    </div>
  );
}

function AddProjectAccessoryModal({ projectCode, projectEntries, onClose }: { projectCode: string | null, projectEntries: ProjectEntry[], onClose: () => void }) {
  const { user } = useAuth();
  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(false);

  const handleAdd = async () => {
    if (!user || !projectCode || !name) return;
    setLoading(true);
    try {
      const q = query(collection(db, 'projects'), where('projectCode', '==', projectCode));
      const snap = await getDocs(q);
      const batch = writeBatch(db);
      
      snap.docs.forEach(docSnap => {
        const data = docSnap.data();
        const accessories = [...(data.accessories || [])];
        accessories.push({ name, quantity, issuedQuantity: 0, status: 'Chưa xuất kho' });
        batch.update(docSnap.ref, { accessories });
      });

      await batch.commit();
      await addDoc(collection(db, 'activities'), {
        userId: user.uid, userName: user.displayName || 'Anonymous', userEmail: user.email,
        action: 'Thêm phụ kiện dự án', details: `Thêm PK ${name} (Số lượng ${quantity}/module) vào dự án ${projectCode}`,
        projectCode, timestamp: serverTimestamp()
      });
      onClose();
    } catch (e: any) {
      handleFirestoreError(e, OperationType.UPDATE, 'projects');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[110] p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-white w-full max-w-sm rounded-xl shadow-2xl overflow-hidden p-6 space-y-6">
        <h3 className="text-lg font-bold text-gray-800 uppercase">Thêm Phụ Kiện cho toàn bộ Module</h3>
        <p className="text-[10px] text-gray-400 leading-relaxed italic">Phụ kiện này sẽ được thêm vào tất cả các module trong dự án hiện tại với số lượng tương ứng cho mỗi module.</p>
        <div className="space-y-4">
          <div className="space-y-1"><label className="text-[10px] font-bold text-gray-400 uppercase">Tên Phụ Kiện</label><input className="w-full border rounded-xl px-4 py-3 text-sm focus:border-primary outline-none bg-gray-50" value={name} onChange={e => setName(e.target.value)} placeholder="VD: Ốc vít 4x10" /></div>
          <div className="space-y-1"><label className="text-[10px] font-bold text-gray-400 uppercase">Số lượng mỗi Module</label><input type="number" min={1} className="w-full border rounded-xl px-4 py-3 text-sm focus:border-primary outline-none bg-gray-50" value={quantity} onChange={e => setQuantity(Number(e.target.value))} /></div>
        </div>
        <div className="flex space-x-3 pt-4"><button onClick={onClose} className="flex-1 py-3 text-gray-400 font-bold text-[10px] uppercase">Huỷ</button><button disabled={loading || !name} onClick={handleAdd} className="flex-[2] py-4 bg-orange-500 text-white rounded-xl font-bold text-xs uppercase shadow-lg shadow-orange-100 disabled:opacity-50">{loading ? <Loader2 size={18} className="animate-spin mx-auto" /> : 'Xác nhận thêm'}</button></div>
      </motion.div>
    </div>
  );
}
