/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Layers, Plus, Inbox, Trash2, ArrowLeft, Pencil, CheckCircle, Loader2, Save, X, PlusCircle, ChevronRight } from 'lucide-react';
import { collection, query, where, onSnapshot, orderBy, doc, deleteDoc, updateDoc, addDoc, serverTimestamp } from 'firebase/firestore';
import { useAuth } from '../lib/AuthContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { ProjectEntry, PackingList, PackingItem } from '../types';

interface PackingScreenProps {
  projectEntries: ProjectEntry[];
}

export function PackingScreen({ projectEntries }: PackingScreenProps) {
  const { user } = useAuth();
  const [packingLists, setPackingLists] = useState<PackingList[]>([]);
  const [selectedList, setSelectedList] = useState<PackingList | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createMode, setCreateMode] = useState<'project' | 'manual' | null>(null);
  const [selectedProject, setSelectedProject] = useState('');
  const [manualTitle, setManualTitle] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'packing'),
      where('ownerId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );
    const unsub = onSnapshot(q, (snapshot) => {
      setPackingLists(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as PackingList)));
    }, (err) => handleFirestoreError(err, OperationType.GET, 'packing'));
    return unsub;
  }, [user]);

  const projects = Array.from(new Set(projectEntries.map(p => p.projectCode))).map(code => {
    const entry = projectEntries.find(p => p.projectCode === code);
    return { code, name: entry?.projectName || 'Không tên', displayCode: entry?.displayCode };
  }).reverse();

  const handleCreate = async () => {
    if (!user) return;
    setLoading(true);
    try {
      let title = '';
      let items: PackingItem[] = [];
      let projectCode = '';

      if (createMode === 'project') {
        const p = projects.find(pr => pr.code === selectedProject);
        title = `Packing: ${p?.name || selectedProject}`;
        projectCode = selectedProject;
        const entries = projectEntries.filter(e => e.projectCode === selectedProject);
        items = entries.map(e => ({ name: `${e.cluster || ''} - ${e.moduleCode}`, quantity: e.quantity, packed: false }));
      } else {
        title = manualTitle || 'Packing List Mới';
        items = [];
      }

      await addDoc(collection(db, 'packing'), {
        title,
        projectCode,
        items,
        isCompleted: false,
        ownerId: user.uid,
        createdAt: serverTimestamp()
      });

      // Log activity
      await addDoc(collection(db, 'activities'), {
        userId: user.uid,
        userName: user.displayName || 'Anonymous',
        userEmail: user.email,
        action: 'Tạo Packing List',
        details: `Tạo: ${title} (${projectCode || 'Cá nhân'})`,
        projectCode: projectCode,
        timestamp: serverTimestamp()
      });

      setShowCreateModal(false);
      setCreateMode(null);
      setManualTitle('');
      setSelectedProject('');
    } catch (error) {
       handleFirestoreError(error, OperationType.CREATE, 'packing');
    } finally {
      setLoading(false);
    }
  };

  if (selectedList) {
    return <PackingDetailScreen packingList={selectedList} onBack={() => setSelectedList(null)} />;
  }

  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6 pb-24">
      <div className="flex items-center justify-between border-b border-gray-200 pb-2">
        <h2 className="text-xl font-black text-gray-800 uppercase tracking-widest flex items-center">
          <Layers size={24} className="mr-2 text-primary" />
          Quản Lý Packing
        </h2>
        <button onClick={() => setShowCreateModal(true)} className="p-2 bg-primary text-white rounded-xl shadow-lg shadow-primary/20 hover:scale-105 transition-all">
          <PlusCircle size={24} />
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {packingLists.length > 0 ? (
          packingLists.map(list => (
            <div 
              key={list.id} 
              onClick={() => setSelectedList(list)}
              className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between cursor-pointer hover:shadow-md transition-all active:scale-[0.98]"
            >
              <div className="flex items-center space-x-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${list.isCompleted ? 'bg-green-50 text-green-500' : 'bg-blue-50 text-blue-500'}`}>
                  {list.isCompleted ? <CheckCircle size={24} /> : <Inbox size={24} />}
                </div>
                <div>
                  <h4 className="font-black text-sm text-gray-800 uppercase tracking-tight">{list.title}</h4>
                  <div className="flex items-center space-x-2 mt-1">
                    <span className="text-[10px] font-bold text-gray-400">{list.items.length} mặt hàng</span>
                    <span className="text-gray-200 text-xs">•</span>
                    <span className={`text-[9px] font-black uppercase tracking-widest ${list.isCompleted ? 'text-green-500' : 'text-blue-500'}`}>
                      {list.isCompleted ? 'Hoàn thành' : 'Đang xử lý'}
                    </span>
                  </div>
                </div>
              </div>
              <ChevronRight size={18} className="text-gray-300" />
            </div>
          ))
        ) : (
          <div className="p-16 text-center text-gray-400 bg-white rounded-3xl border border-dashed border-gray-200">
             <Inbox size={48} className="mx-auto mb-4 opacity-10" />
             <p className="text-sm font-bold uppercase tracking-widest opacity-30">Chưa có Packing List</p>
          </div>
        )}
      </div>

      {showCreateModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[100] p-4 backdrop-blur-sm">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden p-6">
            <h3 className="text-lg font-black text-gray-800 uppercase tracking-widest mb-6">Tạo Packing List mới</h3>
            {!createMode ? (
              <div className="grid grid-cols-1 gap-3">
                <button onClick={() => setCreateMode('project')} className="p-6 bg-blue-50 text-blue-600 rounded-2xl font-black uppercase tracking-widest text-[11px] border border-blue-100 flex flex-col items-center hover:bg-blue-100 transition-all">
                  <Layers size={32} className="mb-2" />
                  Theo Dự Án
                </button>
                <button onClick={() => setCreateMode('manual')} className="p-6 bg-purple-50 text-purple-600 rounded-2xl font-black uppercase tracking-widest text-[11px] border border-purple-100 flex flex-col items-center hover:bg-purple-100 transition-all">
                  <PlusCircle size={32} className="mb-2" />
                  Nhập Thủ Công
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {createMode === 'project' ? (
                  <select 
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:border-primary outline-none"
                    value={selectedProject}
                    onChange={e => setSelectedProject(e.target.value)}
                  >
                    <option value="">-- Chọn dự án --</option>
                    {projects.map(p => <option key={p.code} value={p.code}>{p.displayCode || p.code}: {p.name}</option>)}
                  </select>
                ) : (
                  <input 
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:border-primary outline-none"
                    placeholder="Tên danh sách..."
                    value={manualTitle}
                    onChange={e => setManualTitle(e.target.value)}
                  />
                )}
                <div className="flex space-x-3 pt-4">
                  <button onClick={() => setCreateMode(null)} className="flex-1 py-3 text-gray-400 font-bold uppercase text-[10px]">Quay lại</button>
                  <button 
                    disabled={loading || (createMode === 'project' && !selectedProject)}
                    onClick={handleCreate}
                    className="flex-[2] py-4 bg-primary text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-lg active:scale-95 disabled:opacity-50"
                  >
                    {loading ? <Loader2 size={18} className="animate-spin mx-auto" /> : 'Xác nhận tạo'}
                  </button>
                </div>
              </div>
            )}
            <button onClick={() => setShowCreateModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"><X size={20} /></button>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
}

interface PackingDetailScreenProps {
  packingList: PackingList;
  onBack: () => void;
}

function PackingDetailScreen({ packingList, onBack }: PackingDetailScreenProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState<PackingItem[]>(packingList.items);
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState(packingList.title);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const toggleItem = (idx: number) => {
    if (isEditing) return;
    const newItems = [...items];
    newItems[idx].packed = !newItems[idx].packed;
    setItems(newItems);
  };

  const updateList = async () => {
    if (!user || !packingList.id) return;
    setLoading(true);
    try {
      const allPacked = items.every(i => i.packed);
      await updateDoc(doc(db, 'packing', packingList.id), {
        title,
        items,
        isCompleted: allPacked
      });

      // Log activity
      await addDoc(collection(db, 'activities'), {
        userId: user.uid,
        userName: user.displayName || 'Anonymous',
        userEmail: user.email,
        action: 'Cập nhật Packing List',
        details: `Cập nhật: ${title}${allPacked ? ' (Hoàn thành)' : ''}`,
        projectCode: packingList.projectCode || '',
        timestamp: serverTimestamp()
      });

      setTimeout(() => onBack(), 100);
    } catch (error: any) {
      handleFirestoreError(error, OperationType.UPDATE, 'packing');
    } finally {
      setLoading(false);
    }
  };

  const deleteList = async () => {
    if (!user || !packingList.id) return;
    setLoading(true);
    try {
      await deleteDoc(doc(db, 'packing', packingList.id));

      // Log activity
      await addDoc(collection(db, 'activities'), {
        userId: user.uid,
        userName: user.displayName || 'Anonymous',
        userEmail: user.email,
        action: 'Xoá Packing List',
        details: `Xoá: ${packingList.title}`,
        projectCode: packingList.projectCode || '',
        timestamp: serverTimestamp()
      });

      onBack();
    } catch (error: any) {
      handleFirestoreError(error, OperationType.DELETE, 'packing');
    } finally {
      setLoading(false);
    }
  };

  const addItem = () => {
    setItems([...items, { name: 'Mặt hàng mới', quantity: 1, packed: false }]);
  };

  return (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="max-w-xl mx-auto pb-24">
      <div className="flex items-center justify-between mb-8">
        <button onClick={onBack} className="flex items-center text-gray-500 font-black text-[10px] uppercase tracking-widest active:scale-90">
          <ArrowLeft size={16} className="mr-2" /> Quay lại
        </button>
        <button onClick={() => setIsEditing(!isEditing)} className={`p-3 rounded-xl transition-all active:scale-90 ${isEditing ? 'bg-orange-50 text-orange-500' : 'bg-gray-50 text-gray-500'}`}>
          <Pencil size={20} />
        </button>
      </div>

      <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-6 space-y-6">
        {isEditing ? (
          <input 
            className="w-full text-lg font-black text-gray-800 uppercase tracking-tight border-b-2 border-primary outline-none pb-2"
            value={title}
            onChange={e => setTitle(e.target.value)}
          />
        ) : (
          <h2 className="text-xl font-black text-gray-800 uppercase tracking-tight">{title}</h2>
        )}

        <div className="space-y-3">
          {items.map((item, idx) => (
            <div 
              key={idx} 
              onClick={() => toggleItem(idx)}
              className={`p-4 rounded-2xl border flex items-center justify-between transition-all select-none ${isEditing ? 'border-gray-100 bg-gray-50 cursor-default' : item.packed ? 'bg-green-50 border-green-200 cursor-pointer' : 'bg-white border-gray-200 cursor-pointer hover:border-primary active:scale-[0.98]'}`}
            >
              <div className="flex-1 mr-4">
                {isEditing ? (
                  <div className="flex items-center space-x-2">
                    <input 
                      className="flex-1 bg-transparent border-b border-gray-300 font-bold text-sm outline-none"
                      value={item.name}
                      onChange={e => {
                        const next = [...items];
                        next[idx].name = e.target.value;
                        setItems(next);
                      }}
                    />
                    <input 
                      type="number"
                      className="w-16 bg-transparent border-b border-gray-300 font-black text-sm text-center outline-none"
                      value={item.quantity}
                      onChange={e => {
                        const next = [...items];
                        next[idx].quantity = Number(e.target.value);
                        setItems(next);
                      }}
                    />
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setItems(items.filter((_, i) => i !== idx));
                      }}
                      className="text-red-400 hover:text-red-600"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center">
                    <span className={`text-sm font-black uppercase tracking-tight ${item.packed ? 'text-green-600 line-through' : 'text-gray-800'}`}>
                      {item.name}
                    </span>
                    <span className="ml-2 text-xs font-bold text-gray-400 tracking-widest">x{item.quantity}</span>
                  </div>
                )}
              </div>
              {!isEditing && (
                <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all ${item.packed ? 'bg-green-500 border-green-500 text-white' : 'border-gray-200'}`}>
                  {item.packed && <CheckCircle size={18} />}
                </div>
              )}
            </div>
          ))}
          
          {isEditing && (
            <button 
              onClick={addItem}
              className="w-full py-4 border-2 border-dashed border-gray-200 rounded-2xl text-gray-400 font-black uppercase text-[10px] tracking-widest flex items-center justify-center hover:bg-gray-50 transition-all active:scale-95 mt-4"
            >
              <Plus size={16} className="mr-2" /> Thêm mặt hàng
            </button>
          )}
        </div>
      </div>

      <div className="flex space-x-3 pt-6">
        <button
          onClick={() => setShowDeleteConfirm(true)}
          disabled={loading}
          className="w-1/6 py-4 bg-red-50 text-red-500 rounded-xl flex items-center justify-center transition-all shadow-sm active:scale-95 border border-red-100"
        >
          <Trash2 size={24} />
        </button>
        <button
          disabled={loading}
          onClick={updateList}
          className="flex-1 py-4 bg-primary text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-lg active:scale-95 disabled:opacity-50 flex items-center justify-center space-x-2"
        >
          {loading ? <Loader2 size={20} className="animate-spin" /> : isEditing ? 'Lưu thay đổi' : 'Cập nhật Packing'}
        </button>
      </div>

      {/* Delete Confirmation Overlay */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl w-full max-w-xs p-6 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-2 bg-red-500"></div>
            <div className="mb-6 text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trash2 size={32} className="text-red-600" />
              </div>
              <h3 className="text-lg font-black text-gray-800 uppercase tracking-tight mb-2">Xác nhận xoá?</h3>
              <p className="text-sm text-gray-500 leading-relaxed font-medium">Bạn có chắc muốn xoá Packing List này không? Hành động này không thể hoàn tác.</p>
            </div>
            <div className="flex flex-col space-y-3">
              <button 
                onClick={deleteList}
                disabled={loading}
                className="w-full py-4 bg-red-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-lg active:scale-95 disabled:opacity-50 flex items-center justify-center"
              >
                {loading ? <Loader2 size={18} className="animate-spin" /> : 'Đồng ý xoá'}
              </button>
              <button 
                onClick={() => setShowDeleteConfirm(false)}
                disabled={loading}
                className="w-full py-4 bg-gray-100 text-gray-600 rounded-2xl font-black uppercase tracking-widest text-xs active:scale-95 disabled:opacity-50"
              >
                Huỷ bỏ
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
}

