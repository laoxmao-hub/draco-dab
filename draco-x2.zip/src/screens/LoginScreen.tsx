/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { LogIn, Package } from 'lucide-react';
import { useAuth } from '../lib/AuthContext';

export function LoginScreen() {
  const { login } = useAuth();

  return (
    <div className="min-h-screen bg-[#e9ecef] flex flex-col items-center justify-center p-6 font-sans" id="login-screen">
      <div className="w-full max-w-sm" id="login-box">
        <div className="mb-6 text-center" id="login-logo">
          <div className="flex items-center justify-center space-x-2 text-3xl font-light text-gray-800">
             <span className="font-bold">Admin</span>LTE
          </div>
        </div>
        
        <div className="bg-white rounded shadow-md border-t-4 border-primary overflow-hidden" id="login-card">
          <div className="p-8 space-y-6">
            <div className="text-center space-y-2">
              <p className="text-gray-600 text-sm">Chào mừng quay trở lại. Hãy đăng nhập để tiếp tục quản lý kho hàng.</p>
            </div>

            <button
              onClick={login}
              className="w-full bg-[#df4b3b] hover:bg-[#c9302c] text-white font-semibold py-3 px-4 rounded flex items-center justify-center space-x-3 transition-all active:scale-[0.98] shadow-sm uppercase text-xs tracking-wider"
              id="google-login-btn"
            >
              <LogIn size={18} />
              <span>Đăng nhập với Google</span>
            </button>

            <div className="relative py-2 flex items-center justify-center">
              <div className="flex-grow border-t border-gray-100"></div>
              <span className="px-3 text-[10px] text-gray-400 font-bold">THÔNG TIN</span>
              <div className="flex-grow border-t border-gray-100"></div>
            </div>

            <p className="text-[11px] text-gray-400 text-center leading-relaxed italic">
              Bằng việc đăng nhập, hệ thống sẽ tự động đồng bộ kho hàng của bạn với Google Firebase.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
