/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Boxes, Plus, Search, Filter, Trash2, Package, Loader2, Save, X } from 'lucide-react';
import { collection, addDoc, serverTimestamp, deleteDoc, doc, updateDoc } from 'firebase/firestore';
import { useAuth } from '../lib/AuthContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { StockItem } from '../types';

interface InventoryScreenProps {
  items: StockItem[];
  loading: boolean;
}

export function InventoryScreen({ items, loading }: InventoryScreenProps) {
  const { user, role } = useAuth();
  const isPrivileged = role === 'admin' || role === 'mod';
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  const filteredItems = items.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    item.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="space-y-6 pb-24">
      <div className="flex items-center justify-between border-b border-gray-200 pb-2">
        <h2 className="text-xl font-black text-gray-800 uppercase tracking-widest flex items-center">
          <Boxes size={24} className="mr-2 text-primary" />
          Kho Hàng
        </h2>
        {isPrivileged && (
          <button onClick={() => setShowAddModal(true)} className="bg-primary text-white p-2 rounded-xl shadow-lg shadow-primary/20 active:scale-95 transition-all">
            <Plus size={24} />
          </button>
        )}
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <input 
          type="text"
          placeholder="Tìm kiếm mặt hàng, SKU..."
          className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:border-primary outline-none text-sm transition-all shadow-sm"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {loading ? (
          <div className="col-span-full py-12 flex justify-center"><Loader2 className="animate-spin text-primary" size={32} /></div>
        ) : filteredItems.length > 0 ? (
          filteredItems.map(item => (
            <div key={item.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center space-x-4 hover:shadow-md transition-all group relative">
              <div className="w-14 h-14 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400 group-hover:bg-primary/5 group-hover:text-primary transition-colors">
                <Package size={28} />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-black text-sm text-gray-800 uppercase tracking-tight truncate">{item.name}</h4>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{item.sku} • {item.category}</p>
                <div className="mt-2 flex items-center space-x-3">
                   <span className="text-sm font-black text-primary">SL: {item.quantity}</span>
                   <span className="text-[10px] text-gray-300 font-bold">|</span>
                   <span className="text-[10px] text-gray-400 font-black uppercase tracking-tighter">Giá: {item.price.toLocaleString('vi-VN')}đ</span>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full py-16 text-center text-gray-400 bg-white rounded-3xl border border-dashed border-gray-200">
             <Package size={48} className="mx-auto mb-4 opacity-10" />
             <p className="text-sm font-bold uppercase tracking-widest opacity-30">Kho hàng trống</p>
          </div>
        )}
      </div>

      {showAddModal && <AddItemModal onClose={() => setShowAddModal(false)} />}
    </motion.div>
  );
}

function AddItemModal({ onClose }: { onClose: () => void }) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [item, setItem] = useState({ name: '', sku: '', category: 'Vật tư', quantity: 0, price: 0 });

  const handleAdd = async () => {
    if (!user || !item.name || !item.sku) return;
    setLoading(true);
    try {
      await addDoc(collection(db, 'items'), {
        ...item,
        ownerId: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });

      // Log activity
      await addDoc(collection(db, 'activities'), {
        userId: user.uid,
        userName: user.displayName || 'Anonymous',
        userEmail: user.email,
        action: 'Thêm mặt hàng kho',
        details: `Thêm PK: ${item.name} (${item.sku}) SL: ${item.quantity}`,
        timestamp: serverTimestamp()
      });

      onClose();
    } catch (e: any) {
       handleFirestoreError(e, OperationType.UPDATE, 'items');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[110] p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden p-6 space-y-4">
        <h3 className="text-lg font-black text-gray-800 uppercase tracking-widest">Thêm mặt hàng mới</h3>
        <div className="space-y-3">
          <div className="space-y-1">
             <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Tên mặt hàng</label>
             <input className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:border-primary outline-none" value={item.name} onChange={e => setItem({...item, name: e.target.value})} placeholder="VD: Bản lề" />
          </div>
          <div className="space-y-1">
             <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">SKU / Mã hàng</label>
             <input className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:border-primary outline-none font-mono" value={item.sku} onChange={e => setItem({...item, sku: e.target.value.toUpperCase()})} placeholder="VD: PK-001" />
          </div>
          <div className="grid grid-cols-2 gap-3">
             <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Số lượng</label>
                <input type="number" className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:border-primary outline-none text-center" value={item.quantity} onChange={e => setItem({...item, quantity: Number(e.target.value)})} />
             </div>
             <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Đơn giá</label>
                <input type="number" className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:border-primary outline-none text-center" value={item.price} onChange={e => setItem({...item, price: Number(e.target.value)})} />
             </div>
          </div>
        </div>
        <div className="flex space-x-3 pt-4">
          <button onClick={onClose} className="flex-1 py-3 text-gray-400 font-bold uppercase text-[10px]">Huỷ</button>
          <button 
            disabled={loading || !item.name || !item.sku}
            onClick={handleAdd}
            className="flex-[2] py-4 bg-primary text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-lg active:scale-95 disabled:opacity-50"
          >
            {loading ? <Loader2 size={18} className="animate-spin mx-auto" /> : 'Xác nhận thêm'}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
