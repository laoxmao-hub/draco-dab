/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Users, Shield, User, Loader2, Save, X, Search, ChevronRight } from 'lucide-react';
import { doc, updateDoc, addDoc, serverTimestamp, collection } from 'firebase/firestore';
import { useAuth } from '../lib/AuthContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { UserProfile } from '../types';

interface UserManagementScreenProps {
  allUsers: UserProfile[];
}

export function UserManagementScreen({ allUsers }: UserManagementScreenProps) {
  const { user, role } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);

  const filteredUsers = allUsers.filter(u => 
    (u.ten_that || u.displayName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (u.email || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (role !== 'admin') {
    return (
      <div className="p-12 text-center text-gray-400">
        <Shield size={48} className="mx-auto mb-4 opacity-10" />
        <p className="text-sm font-black uppercase tracking-widest">Quyền truy cập bị từ chối</p>
        <p className="text-xs mt-1 uppercase tracking-tight">Vui lòng liên hệ quản trị viên.</p>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6 pb-24">
      <div className="flex items-center justify-between border-b border-gray-200 pb-2">
        <h2 className="text-xl font-black text-gray-800 uppercase tracking-widest flex items-center">
          <Users size={24} className="mr-2 text-primary" />
          Quản Lý Nhân Viên
        </h2>
        <span className="text-xs text-gray-500 font-normal">Tổng: {allUsers.length}</span>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <input 
          type="text"
          placeholder="Tìm kiếm nhân viên..."
          className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:border-primary outline-none text-sm transition-all shadow-sm"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 gap-3">
        {filteredUsers.map(u => (
          <div 
            key={u.uid} 
            onClick={() => setSelectedUser(u)}
            className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between hover:bg-gray-50 transition-all cursor-pointer group"
          >
            <div className="flex items-center space-x-3">
              <img src={u.photoURL || ''} alt={u.displayName} className="w-10 h-10 rounded-full border border-gray-100" />
              <div>
                <h4 className="text-sm font-black text-gray-800 uppercase tracking-tight">{u.ten_that || u.displayName}</h4>
                <div className="flex items-center space-x-2 mt-0.5">
                  <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${
                    u.role === 'admin' ? 'bg-red-50 text-red-600 border-red-100' : 
                    u.role === 'mod' ? 'bg-blue-50 text-blue-600 border-blue-100' : 'bg-gray-50 text-gray-500 border-gray-200'
                  }`}>
                    {u.role === 'admin' ? 'QUẢN TRỊ' : u.role === 'mod' ? 'ĐIỀU PHỐI' : 'THÀNH VIÊN'}
                  </span>
                  <span className="text-[10px] text-gray-400 font-medium">{u.email}</span>
                </div>
              </div>
            </div>
            <ChevronRight size={16} className="text-gray-300 group-hover:text-primary transition-colors" />
          </div>
        ))}
      </div>

      {selectedUser && (
        <UserEditModal 
          profile={selectedUser} 
          onClose={() => setSelectedUser(null)} 
        />
      )}
    </motion.div>
  );
}

function UserEditModal({ profile, onClose }: { profile: UserProfile, onClose: () => void }) {
  const { user } = useAuth();
  const [role, setRole] = useState(profile.role || 'viewer');
  const [loading, setLoading] = useState(false);

  const handleUpdate = async () => {
    if (!user || user.uid === profile.uid) return alert('Không thể tự sửa quyền của chính mình');
    setLoading(true);
    try {
      await updateDoc(doc(db, 'users', profile.uid), { role });
      
      // Log activity
      await addDoc(collection(db, 'activities'), {
        userId: user.uid,
        userName: user.displayName || 'Anonymous',
        userEmail: user.email,
        action: 'Cập nhật phân quyền',
        details: `Cập nhật quyền của ${profile.displayName} thành ${role}`,
        timestamp: serverTimestamp()
      });

      onClose();
    } catch (e: any) {
      handleFirestoreError(e, OperationType.UPDATE, 'users');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[110] p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden p-6 space-y-6">
        <div className="flex items-center space-x-3">
          <img src={profile.photoURL || ''} alt={profile.displayName} className="w-12 h-12 rounded-full border border-gray-200" />
          <div>
            <h3 className="text-lg font-black text-gray-800 uppercase tracking-tight">{profile.ten_that || profile.displayName}</h3>
            <p className="text-xs text-gray-400 font-bold">{profile.email}</p>
          </div>
        </div>

        <div className="space-y-4 pt-4 border-t border-gray-50">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Phân quyền hệ thống</label>
            <div className="grid grid-cols-1 gap-2">
              {['admin', 'mod', 'viewer'].map(r => (
                <button 
                  key={r}
                  onClick={() => setRole(r as any)}
                  className={`flex items-center justify-between px-4 py-3 rounded-xl border transition-all ${
                    role === r ? 'bg-primary/5 border-primary text-primary shadow-sm' : 'bg-gray-50 border-gray-100 text-gray-400'
                  }`}
                >
                  <span className="text-xs font-black uppercase tracking-widest">
                    {r === 'admin' ? 'Quản trị viên' : r === 'mod' ? 'Điều phối viên' : 'Thành viên xem'}
                  </span>
                  {role === r && <Shield size={16} />}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex space-x-3 pt-4">
          <button onClick={onClose} className="flex-1 py-3 text-gray-400 font-bold uppercase text-[10px]">Huỷ</button>
          <button 
            disabled={loading || role === profile.role}
            onClick={handleUpdate}
            className="flex-[2] py-4 bg-primary text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-lg active:scale-95 disabled:opacity-50 flex items-center justify-center space-x-2"
          >
            {loading ? <Loader2 size={18} className="animate-spin" /> : <span>Lưu thay đổi</span>}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
