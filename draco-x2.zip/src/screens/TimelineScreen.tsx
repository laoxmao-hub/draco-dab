/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { History, Menu, Loader2, Clock } from 'lucide-react';
import { query, collection, orderBy, onSnapshot, where } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { ActivityLog, ActivityFilter, UserProfile } from '../types';

interface TimelineScreenProps {
  filter: ActivityFilter;
  allUsers: UserProfile[];
  onOpenFilter: () => void;
}

export function TimelineScreen({ filter, allUsers, onOpenFilter }: TimelineScreenProps) {
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);

  const usersMap = React.useMemo(() => {
    const map: Record<string, UserProfile> = {};
    allUsers.forEach(u => {
      if (u.email) map[u.email.toLowerCase()] = u;
      if (u.uid) map[u.uid] = u;
    });
    return map;
  }, [allUsers]);

  useEffect(() => {
    let q = query(collection(db, 'activities'), orderBy('timestamp', 'desc'));
    
    if (filter.projectCode) {
      q = query(q, where('projectCode', '==', filter.projectCode));
    }
    if (filter.userEmail) {
      q = query(q, where('userEmail', '==', filter.userEmail));
    }

    const unsubLogs = onSnapshot(q, (snapshot) => {
      let filteredLogs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ActivityLog));
      
      if (filter.startDate) {
        const start = new Date(filter.startDate);
        start.setHours(0, 0, 0, 0);
        filteredLogs = filteredLogs.filter(l => {
          const d = l.timestamp?.toDate ? l.timestamp.toDate() : new Date(l.timestamp);
          return d >= start;
        });
      }
      if (filter.endDate) {
        const end = new Date(filter.endDate);
        end.setHours(23, 59, 59, 999);
        filteredLogs = filteredLogs.filter(l => {
          const d = l.timestamp?.toDate ? l.timestamp.toDate() : new Date(l.timestamp);
          return d <= end;
        });
      }

      setLogs(filteredLogs.slice(0, 50));
      setLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'activities');
      setLoading(false);
    });

    return () => {
      unsubLogs();
    };
  }, [filter]);

  const formatFullDate = (ts: any) => {
    if (!ts) return { time: '', date: '', month: '' };
    const date = ts.toDate ? ts.toDate() : new Date(ts);
    return {
      time: date.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
      date: date.getDate().toString().padStart(2, '0'),
      month: `THG ${date.getMonth() + 1}`,
      year: date.getFullYear()
    };
  };

  const hasActiveFilter = filter.projectCode || filter.userEmail || filter.startDate || filter.endDate;

  return (
    <div className="max-w-[95%] w-full mx-auto pb-24">
      <div className="mb-8 flex items-center justify-between sticky top-0 bg-[#f4f6f9]/80 backdrop-blur-md py-4 z-10 border-b border-gray-100">
        <div className="flex flex-col">
          <h2 className="text-xl font-black text-gray-800 uppercase tracking-widest flex items-center">
            <History size={24} className="mr-2 text-primary" />
            Dòng Thời Gian
          </h2>
          {hasActiveFilter && (
            <span className="text-[9px] font-black text-primary uppercase tracking-widest mt-0.5">
              • Đang bật bộ lọc dữ liệu
            </span>
          )}
        </div>
        <button 
          onClick={onOpenFilter}
          className={`flex items-center space-x-2 px-4 py-2 rounded-xl border font-black text-[11px] uppercase tracking-widest transition-all active:scale-95 ${
            hasActiveFilter 
              ? 'bg-primary text-white border-primary shadow-lg shadow-primary/20' 
              : 'bg-white text-gray-600 border-gray-200 hover:border-primary hover:text-primary shadow-sm'
          }`}
        >
          <Menu size={16} />
          <span>Bộ Lọc</span>
          {hasActiveFilter && <div className="w-2 h-2 bg-white rounded-full ml-1"></div>}
        </button>
      </div>

      <div className="relative">
        <div className="absolute left-[15%] sm:left-[20%] top-0 bottom-0 w-1 bg-gray-200"></div>

        <div className="space-y-8">
          {loading ? (
            <div className="flex justify-center p-12">
              <Loader2 size={32} className="animate-spin text-primary" />
            </div>
          ) : logs.length > 0 ? (
            logs.map((log, idx) => {
              const emailKey = (log.userEmail || '').toLowerCase();
              const userId = (log as any).userId;
              const userProfile = usersMap[emailKey] || (userId ? usersMap[userId] : null);
              const displayTitle = userProfile?.chuc_danh || (userProfile?.role === 'admin' ? 'Quản trị' : userProfile?.role === 'mod' ? 'Điều phối' : 'Thành viên');
              const displayName = userProfile?.ten_that || log.userName || log.userEmail;
              const dateInfo = formatFullDate(log.timestamp);
              
              const isDelete = log.action.includes('Xóa');
              const isUpdate = log.action.includes('Cập nhật') || log.action.includes('Sửa');
              const isExcel = log.action.includes('Excel');

              return (
                <div key={log.id} className="relative flex items-start group">
                  <div className="w-[15%] sm:w-[20%] text-right pr-6 sm:pr-10 pt-1 flex flex-col">
                    <span className="text-xl sm:text-2xl font-black text-gray-800 leading-none">{dateInfo.date}</span>
                    <span className="text-[10px] sm:text-[11px] font-bold text-gray-400 uppercase tracking-tighter">{dateInfo.month}</span>
                    <span className="text-[11px] sm:text-xs font-black text-primary mt-1">{dateInfo.time}</span>
                  </div>

                  <div className="absolute left-[15%] sm:left-[20%] -translate-x-1/2 z-10 mt-1.5">
                    <div className={`w-5 h-5 rounded-full border-4 bg-white transition-all shadow-sm ${
                      isDelete ? 'border-danger scale-110' : 
                      isExcel ? 'border-success' : 
                      isUpdate ? 'border-info' : 'border-primary'
                    }`}></div>
                  </div>

                  <div className="flex-1 ml-4 sm:ml-8 relative">
                    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 hover:shadow-md transition-all active:scale-[0.99] group-hover:border-primary/20">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-black text-gray-800 uppercase tracking-tight">
                            {displayName}
                          </span>
                          <span className="text-[9px] bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full font-bold uppercase tracking-widest border border-gray-200">
                            {displayTitle}
                          </span>
                        </div>
                      </div>

                      <div className="text-sm text-gray-600 leading-relaxed">
                        <span className={`font-black uppercase text-[11px] tracking-tight mr-1 ${
                          isDelete ? 'text-danger' : 
                          isExcel ? 'text-success' : 
                          isUpdate ? 'text-info' : 'text-primary'
                        }`}>
                          {log.action}
                        </span>
                        <span className="mx-1 opacity-20">|</span>
                        <span className="font-medium">{log.details}</span>
                      </div>

                      {(log.projectCode || log.moduleCode) && (
                        <div className="mt-3 flex items-center gap-2 flex-wrap">
                          {log.projectCode && (
                            <span className="text-[9px] bg-blue-50 text-blue-700 px-2.5 py-1 rounded-lg font-black uppercase tracking-widest border border-blue-100">
                              Dự án: {log.projectCode}
                            </span>
                          )}
                          {log.moduleCode && (
                            <span className="text-[9px] bg-purple-50 text-purple-700 px-2.5 py-1 rounded-lg font-black uppercase tracking-widest border border-purple-100">
                              Module: {log.moduleCode}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="p-16 text-center text-gray-400 italic bg-white rounded-2xl shadow-inner border border-dashed border-gray-200 ml-20">
              <Clock size={48} className="mx-auto mb-4 opacity-10" />
              <p className="text-base font-bold uppercase tracking-widest">Trống</p>
              <p className="text-xs mt-1 uppercase tracking-tight">Không tìm thấy hoạt động nào phù hợp với bộ lọc</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function TimelineFilterModal({ 
  filter, 
  setFilter, 
  onClose,
  projects,
  emails
}: { 
  filter: ActivityFilter, 
  setFilter: (f: ActivityFilter) => void, 
  onClose: () => void,
  projects: { code: string, displayCode?: string }[],
  emails: string[]
}) {
  const [localFilter, setLocalFilter] = useState(filter);

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60] p-4 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }} 
        animate={{ opacity: 1, scale: 1 }} 
        className="bg-white w-full max-w-sm rounded-xl shadow-2xl overflow-hidden"
      >
        <div className="p-4 bg-primary text-white flex items-center space-x-2">
          <History size={20} />
          <h3 className="font-bold text-sm uppercase tracking-wider">Phân loại hoạt động</h3>
        </div>
        <div className="p-6 space-y-4">
          <div className="space-y-1">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Mã Dự Án</label>
            <select 
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-primary outline-none"
              value={localFilter.projectCode}
              onChange={e => setLocalFilter({...localFilter, projectCode: e.target.value})}
            >
              <option key="all-projects" value="">Tất cả dự án</option>
              {projects.map(p => (
                <option key={p.code} value={p.code}>{p.displayCode || p.code}</option>
              ))}
            </select>
          </div>
          
          <div className="space-y-1">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Người thực hiện</label>
            <select 
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-primary outline-none"
              value={localFilter.userEmail}
              onChange={e => setLocalFilter({...localFilter, userEmail: e.target.value})}
            >
              <option key="all-users" value="">Tất cả nhân viên</option>
              {emails.map(email => (
                <option key={email} value={email}>{email}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Từ ngày</label>
              <input 
                type="date"
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-primary outline-none"
                value={localFilter.startDate}
                onChange={e => setLocalFilter({...localFilter, startDate: e.target.value})}
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Đến ngày</label>
              <input 
                type="date"
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-primary outline-none"
                value={localFilter.endDate}
                onChange={e => setLocalFilter({...localFilter, endDate: e.target.value})}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-4 border-t border-gray-50">
            <button 
              onClick={() => {
                setFilter({ projectCode: '', userEmail: '', startDate: '', endDate: '' });
                onClose();
              }}
              className="py-3 bg-gray-100 text-gray-500 font-black rounded-xl text-[10px] uppercase tracking-widest hover:bg-gray-200 transition-all active:scale-95"
            >
              Xóa lọc
            </button>
            <button 
              onClick={() => {
                setFilter(localFilter);
                onClose();
              }}
              className="py-3 bg-primary text-white font-black rounded-xl text-[10px] uppercase tracking-widest shadow-lg shadow-primary/20 hover:bg-blue-700 transition-all active:scale-95"
            >
              Áp dụng
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
