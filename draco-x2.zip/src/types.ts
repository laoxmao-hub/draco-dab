/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Tab = 'management' | 'excel' | 'edit' | 'timeline' | 'packing' | 'inventory' | 'users';

export interface PackingItem {
  name: string;
  quantity: number;
  packed: boolean;
}

export interface PackingList {
  id: string;
  title: string;
  projectCode?: string;
  items: PackingItem[];
  isCompleted: boolean;
  ownerId: string;
  createdAt: any;
}

export interface StockItem {
  id?: string;
  name: string;
  sku: string;
  category: string;
  price: number;
  quantity: number;
  imageUrl?: string;
  ownerId: string;
  createdAt: any;
  updatedAt: any;
}

export interface Accessory {
  name: string;
  quantity: number;
  issuedQuantity?: number;
  status?: string;
}

export interface ProjectEntry {
  id: string;
  projectName: string;
  projectCode: string;
  displayCode?: string;
  cluster: string;
  moduleCode: string;
  quantity: number;
  accessories?: Accessory[];
  status?: string;
  statusHistory?: string[];
  ownerId: string;
  createdAt: any;
  sortIndex?: number;
}

export interface ActivityLog {
  id: string;
  userName: string;
  userEmail: string;
  action: string;
  details: string;
  timestamp: any;
  projectCode?: string;
  moduleCode?: string;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  chuc_danh?: string;
  ten_that?: string;
  role?: string;
}

export interface ActivityFilter {
  projectCode: string;
  userEmail: string;
  startDate: string;
  endDate: string;
}
