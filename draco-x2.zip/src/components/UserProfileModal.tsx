/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Save, Loader2, User } from 'lucide-react';
import { doc, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { UserProfile } from '../types';

export function UserProfileModal({ 
  profile,
  onClose 
}: { 
  profile: UserProfile,
  onClose: () => void 
}) {
  const [tenThat, setTenThat] = useState(profile.ten_that || '');
  const [chucDanh, setChucDanh] = useState(profile.chuc_danh || '');
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    try {
      const userRef = doc(db, 'users', profile.uid);
      await updateDoc(userRef, {
        ten_that: tenThat,
        chuc_danh: chucDanh
      });
      onClose();
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'users');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[70] p-4 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }} 
        animate={{ opacity: 1, scale: 1 }} 
        className="bg-white w-full max-w-sm rounded-xl shadow-2xl overflow-hidden"
      >
        <div className="p-4 bg-gray-800 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <User size={20} />
            <h3 className="font-bold text-sm uppercase tracking-wider">Thông tin cá nhân</h3>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-white/20 rounded-full transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-6 space-y-6">
          <div className="flex flex-col items-center space-y-3">
            <img 
              src={profile.photoURL || ''} 
              alt={profile.displayName} 
              referrerPolicy="no-referrer" 
              className="w-20 h-20 rounded-full border-4 border-gray-50 shadow-md"
            />
            <div className="text-center">
              <h4 className="text-base font-black text-gray-800 uppercase tracking-tight">{profile.displayName}</h4>
              <p className="text-xs text-gray-400 font-bold">{profile.email}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Họ & Tên thật</label>
              <input 
                className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:border-primary outline-none bg-gray-50 font-bold"
                placeholder="VD: Nguyễn Văn A"
                value={tenThat}
                onChange={e => setTenThat(e.target.value)}
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Chức danh / Vị trí</label>
              <input 
                className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:border-primary outline-none bg-gray-50 font-bold"
                placeholder="VD: Trưởng phòng kỹ thuật"
                value={chucDanh}
                onChange={e => setChucDanh(e.target.value)}
              />
            </div>
          </div>

          <button 
            disabled={loading}
            onClick={handleSave}
            className="w-full py-4 bg-primary text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-lg shadow-primary/20 hover:bg-blue-700 transition-all active:scale-95 flex items-center justify-center space-x-2 disabled:opacity-50"
          >
            {loading ? <Loader2 size={18} className="animate-spin" /> : (
              <>
                <Save size={18} />
                <span>Lưu thông tin</span>
              </>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
